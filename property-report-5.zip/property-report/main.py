"""الواجهة الرئيسية لنظام إنشاء التقرير المساحي."""

import os
import sys
from datetime import datetime

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from clipboard_reader import read_clipboard
from parser import parse_clipboard, validate, build_ordered_data
from pdf_generator import generate_pdf

from config import (
    REQUIRED_FIELDS,
    FIELD_ORDER,
    DEFAULT_MAIN_TITLE,
    DEFAULT_COMPANY_TITLE,
    COLOR_PRIMARY,
    COLOR_BUTTON,
    COLOR_BUTTON_ACTIVE,
    COLOR_DELETE,
    COLOR_DELETE_ACTIVE,
)


class App:
    def __init__(self, root: tk.Tk):
        self.root = root

        self.data = {}
        self.aerial_image = None

        self.main_title = DEFAULT_MAIN_TITLE
        self.company_title = DEFAULT_COMPANY_TITLE

        self.edit_entry = None
        self.edit_item = None
        self.edit_column = None

        self.output = self._get_output_folder()

        self._configure_window()
        self._build_ui()

    # ══════════════════════════════════════════════════════════
    # الإعدادات
    # ══════════════════════════════════════════════════════════

    def _get_output_folder(self):
        desktop = os.path.join(
            os.path.expanduser("~"),
            "Desktop",
        )

        folder = os.path.join(
            desktop,
            "Survey Reports",
        )

        os.makedirs(folder, exist_ok=True)

        return folder

    def _configure_window(self):
        self.root.title("نظام إنشاء تقرير مساحي")
        self.root.geometry("1180x780")
        self.root.minsize(950, 650)
        self.root.configure(bg="#EEF2F6")

    # ══════════════════════════════════════════════════════════
    # الواجهة
    # ══════════════════════════════════════════════════════════

    def _build_ui(self):
        self._build_header()
        self._build_content()
        self._build_status_bar()

    def _build_header(self):
        header = tk.Frame(
            self.root,
            bg=COLOR_PRIMARY,
            height=70,
        )
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Label(
            header,
            text="نظام إنشاء التقرير المساحي",
            font=("Segoe UI", 17, "bold"),
            bg=COLOR_PRIMARY,
            fg="white",
        ).pack(
            side="right",
            padx=25,
            pady=18,
        )

        tk.Label(
            header,
            text="إدخال البيانات وإنشاء التقرير PDF",
            font=("Segoe UI", 9),
            bg=COLOR_PRIMARY,
            fg="#DDE8F2",
        ).pack(
            side="right",
            padx=(0, 20),
            pady=22,
        )

    def _build_content(self):
        container = tk.Frame(
            self.root,
            bg="#EEF2F6",
        )
        container.pack(
            fill="both",
            expand=True,
            padx=18,
            pady=18,
        )

        # ──────────────────────────────────────────────────────
        # لوحة التحكم
        # ──────────────────────────────────────────────────────

        controls = tk.Frame(
            container,
            bg="white",
            width=210,
            highlightbackground="#D7DEE6",
            highlightthickness=1,
        )
        controls.pack(
            side="right",
            fill="y",
            padx=(14, 0),
        )
        controls.pack_propagate(False)

        tk.Label(
            controls,
            text="التحكم",
            font=("Segoe UI", 13, "bold"),
            bg="white",
            fg=COLOR_PRIMARY,
        ).pack(
            pady=(18, 14),
        )

        self._make_button(
            controls,
            "📋  لصق البيانات",
            self.on_paste,
        )

        self._make_button(
            controls,
            "🖼  رفع الصورة الجوية",
            self.on_upload_image,
        )

        self._make_button(
            controls,
            "🗑  حذف الصورة",
            self.on_remove_image,
            delete=True,
        )

        self._make_button(
            controls,
            "🖨  إنشاء PDF",
            self.on_print,
        )

        separator = tk.Frame(
            controls,
            bg="#E5E9EE",
            height=1,
        )
        separator.pack(
            fill="x",
            padx=18,
            pady=18,
        )

        self.image_status_var = tk.StringVar(
            value="لا توجد صورة جوية"
        )

        tk.Label(
            controls,
            textvariable=self.image_status_var,
            font=("Segoe UI", 8),
            bg="white",
            fg="#667085",
            wraplength=175,
            justify="right",
        ).pack(
            padx=15,
            pady=4,
        )

        self.file_var = tk.StringVar(value="")

        tk.Label(
            controls,
            textvariable=self.file_var,
            font=("Segoe UI", 8),
            bg="white",
            fg="#2F855A",
            wraplength=175,
            justify="right",
        ).pack(
            side="bottom",
            padx=15,
            pady=15,
        )

        # ──────────────────────────────────────────────────────
        # المعاينة
        # ──────────────────────────────────────────────────────

        preview = tk.Frame(
            container,
            bg="white",
            highlightbackground="#D7DEE6",
            highlightthickness=1,
        )
        preview.pack(
            side="left",
            fill="both",
            expand=True,
        )

        top = tk.Frame(
            preview,
            bg="white",
            height=50,
        )
        top.pack(
            fill="x",
            padx=14,
        )
        top.pack_propagate(False)

        tk.Label(
            top,
            text="معاينة البيانات",
            font=("Segoe UI", 12, "bold"),
            bg="white",
            fg=COLOR_PRIMARY,
        ).pack(
            side="right",
            pady=14,
        )

        tk.Label(
            top,
            text="انقر مرتين على أي قيمة لتعديلها",
            font=("Segoe UI", 8),
            bg="white",
            fg="#7A8694",
        ).pack(
            side="left",
            pady=16,
        )

        table_frame = tk.Frame(
            preview,
            bg="white",
        )
        table_frame.pack(
            fill="both",
            expand=True,
            padx=12,
            pady=(0, 12),
        )

        style = ttk.Style()

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Treeview",
            background="white",
            fieldbackground="white",
            foreground="#202B36",
            rowheight=30,
            font=("Segoe UI", 9),
            borderwidth=0,
        )

        style.configure(
            "Treeview.Heading",
            background=COLOR_PRIMARY,
            foreground="white",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
        )

        style.map(
            "Treeview",
            background=[
                ("selected", "#DCEAF5"),
            ],
            foreground=[
                ("selected", "#163B59"),
            ],
        )

        self.tree = ttk.Treeview(
            table_frame,
            columns=("field", "value"),
            show="headings",
        )

        self.tree.heading(
            "field",
            text="الحقل",
        )

        self.tree.heading(
            "value",
            text="القيمة",
        )

        self.tree.column(
            "field",
            width=280,
            anchor="e",
            stretch=False,
        )

        self.tree.column(
            "value",
            width=520,
            anchor="e",
            stretch=True,
        )

        scroll = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.tree.yview,
        )

        self.tree.configure(
            yscrollcommand=scroll.set,
        )

        self.tree.pack(
            side="left",
            fill="both",
            expand=True,
        )

        scroll.pack(
            side="right",
            fill="y",
        )

        self.tree.bind(
            "<Double-1>",
            self._start_inline_edit,
        )

    def _build_status_bar(self):
        self.status_var = tk.StringVar(
            value="جاهز — الصق البيانات للبدء"
        )

        status = tk.Label(
            self.root,
            textvariable=self.status_var,
            bg="#E5EAF0",
            fg="#536170",
            font=("Segoe UI", 8),
            anchor="e",
            padx=15,
            pady=6,
        )

        status.pack(
            fill="x",
            side="bottom",
        )

    # ══════════════════════════════════════════════════════════
    # الأزرار
    # ══════════════════════════════════════════════════════════

    def _make_button(
        self,
        parent,
        text,
        command,
        delete=False,
    ):
        bg = COLOR_DELETE if delete else COLOR_BUTTON
        active = COLOR_DELETE_ACTIVE if delete else COLOR_BUTTON_ACTIVE

        button = tk.Button(
            parent,
            text=text,
            command=command,
            font=("Segoe UI", 9, "bold"),
            bg=bg,
            fg="white",
            activebackground=active,
            activeforeground="white",
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=8,
            pady=10,
        )

        button.pack(
            fill="x",
            padx=16,
            pady=5,
        )

        return button

    def set_status(self, text):
        self.status_var.set(text)

    # ══════════════════════════════════════════════════════════
    # المعاينة
    # ══════════════════════════════════════════════════════════

    def refresh_tree(self):
        self._cancel_inline_edit()

        for item in self.tree.get_children():
            self.tree.delete(item)

        for key, value in self.data.items():
            if value is not None:
                self.tree.insert(
                    "",
                    "end",
                    values=(
                        key,
                        value,
                    ),
                )

    # ══════════════════════════════════════════════════════════
    # التعديل المباشر
    # ══════════════════════════════════════════════════════════

    def _start_inline_edit(self, event):
        self._cancel_inline_edit()

        item = self.tree.identify_row(event.y)
        column = self.tree.identify_column(event.x)

        # السماح بتعديل عمود القيمة فقط
        if not item or column != "#2":
            return

        bbox = self.tree.bbox(item, column)

        if not bbox:
            return

        x, y, width, height = bbox

        values = self.tree.item(item, "values")

        if len(values) < 2:
            return

        current_value = values[1]

        entry = tk.Entry(
            self.tree,
            font=("Segoe UI", 9),
            justify="right",
            relief="solid",
            bd=1,
            bg="#FFFDF2",
        )

        entry.insert(0, current_value)

        entry.place(
            x=x,
            y=y,
            width=width,
            height=height,
        )

        entry.focus_set()
        entry.select_range(0, "end")

        self.edit_entry = entry
        self.edit_item = item
        self.edit_column = column

        entry.bind(
            "<Return>",
            lambda e: self._save_inline_edit(),
        )

        entry.bind(
            "<Escape>",
            lambda e: self._cancel_inline_edit(),
        )

        entry.bind(
            "<FocusOut>",
            lambda e: self._save_inline_edit(),
        )

    def _save_inline_edit(self):
        if not self.edit_entry or not self.edit_item:
            return

        value = self.edit_entry.get().strip()

        values = list(
            self.tree.item(
                self.edit_item,
                "values",
            )
        )

        if len(values) >= 2:
            key = values[0]

            self.data[key] = value

            values[1] = value

            self.tree.item(
                self.edit_item,
                values=values,
            )

        self._cancel_inline_edit()

        self.set_status("✓ تم حفظ التعديل")

    def _cancel_inline_edit(self):
        if self.edit_entry:
            try:
                self.edit_entry.destroy()
            except tk.TclError:
                pass

        self.edit_entry = None
        self.edit_item = None
        self.edit_column = None

    # ══════════════════════════════════════════════════════════
    # لصق البيانات
    # ══════════════════════════════════════════════════════════

    def on_paste(self):
        text = read_clipboard()

        if not text:
            messagebox.showwarning(
                "الحافظة فارغة",
                "انسخ البيانات من إضافة المتصفح أولًا.",
            )
            return

        data = parse_clipboard(text)

        if not data:
            messagebox.showerror(
                "خطأ في البيانات",
                "لم يتم التعرف على صيغة البيانات.",
            )
            return

        valid, missing = validate(
            data,
            REQUIRED_FIELDS,
        )

        self.data = build_ordered_data(
            data,
            FIELD_ORDER,
        )

        self.refresh_tree()

        filled = sum(
            1
            for value in self.data.values()
            if value
        )

        if valid:
            self.set_status(
                f"✓ تم تحميل البيانات — {filled} حقل"
            )
        else:
            self.set_status(
                f"⚠ البيانات محملة — يوجد {len(missing)} حقل ناقص"
            )

            messagebox.showwarning(
                "حقول ناقصة",
                "الحقول التالية فارغة:\n\n"
                + "\n".join(
                    f"• {field}"
                    for field in missing
                ),
            )

    # ══════════════════════════════════════════════════════════
    # الصورة الجوية
    # ══════════════════════════════════════════════════════════

    def on_upload_image(self):
        path = filedialog.askopenfilename(
            title="اختر الصورة الجوية",
            filetypes=[
                (
                    "ملفات الصور",
                    "*.png *.jpg *.jpeg *.bmp",
                ),
                (
                    "جميع الملفات",
                    "*.*",
                ),
            ],
        )

        if not path:
            return

        self.aerial_image = path

        filename = os.path.basename(path)

        if len(filename) > 28:
            filename = filename[:25] + "..."

        self.image_status_var.set(
            f"✓ {filename}"
        )

        self.set_status(
            "✓ تم اختيار الصورة الجوية"
        )

    def on_remove_image(self):
        self.aerial_image = None

        self.image_status_var.set(
            "لا توجد صورة جوية"
        )

        self.set_status(
            "✓ تم حذف الصورة الجوية"
        )

    # ══════════════════════════════════════════════════════════
    # إنشاء PDF
    # ══════════════════════════════════════════════════════════

    def on_print(self):
        self._cancel_inline_edit()

        if not self.data:
            messagebox.showinfo(
                "تنبيه",
                "الصق البيانات أولًا.",
            )
            return

        try:
            timestamp = datetime.now().strftime(
                "%Y-%m-%d_%H-%M-%S"
            )

            parcel = (
                str(
                    self.data.get(
                        "رقم القطعة بالمخطط",
                        "unknown",
                    )
                ).strip()
                or "unknown"
            )

            path = generate_pdf(
                self.data,
                output_path=os.path.join(
                    self.output,
                    f"Survey Report_{parcel}_{timestamp}.pdf",
                ),
                aerial_image=self.aerial_image,
                main_title=self.main_title,
                company_title=self.company_title,
            )

            self.file_var.set(
                f"✓ {os.path.basename(path)}"
            )

            self.set_status(
                "✓ تم إنشاء التقرير بنجاح"
            )

            self._open_file(path)

        except Exception as exc:
            messagebox.showerror(
                "خطأ",
                f"تعذر إنشاء PDF:\n\n{exc}",
            )

            self.set_status(
                "✗ فشل إنشاء التقرير"
            )

    @staticmethod
    def _open_file(path):
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)

            elif sys.platform == "darwin":
                os.system(
                    f'open "{path}"'
                )

            else:
                os.system(
                    f'xdg-open "{path}"'
                )

        except Exception:
            pass


def main():
    root = tk.Tk()

    App(root)

    root.mainloop()


if __name__ == "__main__":
    main()
