@echo off
chcp 65001 > nul
cd /d "%~dp0"
if exist "%~dp0SurveyReport.exe" (
    start "" "%~dp0SurveyReport.exe"
) else (
    python main.py
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo حدث خطأ أثناء تشغيل البرنامج.
        pause
    )
)
