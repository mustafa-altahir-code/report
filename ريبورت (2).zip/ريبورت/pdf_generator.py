"""توليد التقرير المساحي PDF."""

import os
import re
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

import arabic_reshaper
from bidi.algorithm import get_display

from config import (
    FONT_REGULAR,
    FONT_BOLD,
    LOGO_RER,
    LOGO_QR,
    OUTPUT_DIR,
    COLOR_PRIMARY,
    COLOR_SECONDARY,
    COLOR_COMPANY,
    COLOR_WHITE,
    COLOR_BLACK,
    COLOR_LIGHT_GRAY,
    DEFAULT_MAIN_TITLE,
    DEFAULT_COMPANY_TITLE,
    PDF_FONT_NORMAL,
    PDF_FONT_MIN,
    MIN_MAP_HEIGHT_1PAGE,
    MAX_OWNERS_1PAGE,
)




# ══════════════════════════════════════════════════════════════
# إعداد الصفحة
# ══════════════════════════════════════════════════════════════

PAGE_W, PAGE_H = A4

MARGIN = 0.8 * cm

CONTENT_W = PAGE_W - 2 * MARGIN
CONTENT_H = PAGE_H - 2 * MARGIN

C_PRIMARY = colors.HexColor(COLOR_PRIMARY)
C_SECONDARY = colors.HexColor(COLOR_SECONDARY)
C_WHITE = colors.white
C_BLACK = colors.black
C_LIGHT = colors.HexColor("#FAFAFA")
C_COMPANY = colors.HexColor(COLOR_COMPANY)

RADIUS = 4


# ══════════════════════════════════════════════════════════════
# النص العربي
# ══════════════════════════════════════════════════════════════

def ar(text):
    """تجهيز النص العربي لـReportLab."""
    if text is None:
        return ""

    text = str(text)

    if not text:
        return ""

    reshaped = arabic_reshaper.reshape(text)

    return get_display(reshaped)


def register_fonts():
    """تسجيل الخطوط."""
    if "Naskh" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(
            TTFont(
                "Naskh",
                FONT_REGULAR,
            )
        )

    if "Naskh-Bold" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(
            TTFont(
                "Naskh-Bold",
                FONT_BOLD,
            )
        )


# ══════════════════════════════════════════════════════════════
# أدوات النص داخل الخلية
# ══════════════════════════════════════════════════════════════

def text_width(text, font_name, font_size):
    if not text:
        return 0

    return pdfmetrics.stringWidth(
        ar(text),
        font_name,
        font_size,
    )


def wrap_text(text, font_name, font_size, max_width):
    """
    لف النص إلى عدة أسطر حسب عرض الخلية.
    """

    text = str(text or "").strip()

    if not text:
        return [""]

    words = text.split()

    lines = []
    current = ""

    for word in words:
        candidate = (
            f"{current} {word}".strip()
        )

        if (
            not current
            or text_width(
                candidate,
                font_name,
                font_size,
            ) <= max_width
        ):
            current = candidate

        else:
            lines.append(current)
            current = word

    if current:
        lines.append(current)

    return lines or [""]


def calculate_text_layout(
    text,
    width,
    height,
    font_name="Naskh",
    font_size=PDF_FONT_NORMAL,
    min_size=PDF_FONT_MIN,
    padding=4,
    line_spacing=1.15,
):
    """
    حساب أفضل حجم خط وعدد الأسطر.

    الأولوية:
    1. الحفاظ على حجم الخط.
    2. السماح بالالتفاف.
    3. إذا لم يكفِ الارتفاع، تصغير الخط تدريجيًا.
    """

    available_width = max(
        width - padding * 2,
        10,
    )

    available_height = max(
        height - padding * 2,
        10,
    )

    size = font_size

    while size >= min_size:
        lines = wrap_text(
            text,
            font_name,
            size,
            available_width,
        )

        line_height = size * line_spacing
        required_height = (
            len(lines) * line_height
        )

        if required_height <= available_height:
            return size, lines, required_height

        size -= 0.25

    size = min_size

    lines = wrap_text(
        text,
        font_name,
        size,
        available_width,
    )

    return (
        size,
        lines,
        len(lines) * size * line_spacing,
    )


def draw_wrapped_text(
    c,
    x,
    y,
    width,
    height,
    text,
    font_name="Naskh",
    font_size=PDF_FONT_NORMAL,
    min_size=PDF_FONT_MIN,
    color=C_BLACK,
    align="center",
):
    """رسم النص داخل الخلية مع الالتفاف."""

    if not text:
        return

    size, lines, required_height = calculate_text_layout(
        text=text,
        width=width,
        height=height,
        font_name=font_name,
        font_size=font_size,
        min_size=min_size,
    )

    c.setFillColor(color)
    c.setFont(
        font_name,
        size,
    )

    line_height = size * 1.15
    n_lines = len(lines)

    start_y = (
        y
        + height / 2
        + (n_lines - 1) * line_height / 2
        - 0.25 * size
    )

    for index, line in enumerate(lines):
        line_y = (
            start_y
            - index * line_height
        )

        display_line = ar(line)

        if align == "right":
            c.drawRightString(
                x + width - 5,
                line_y,
                display_line,
            )

        elif align == "left":
            c.drawString(
                x + 5,
                line_y,
                display_line,
            )

        else:
            c.drawCentredString(
                x + width / 2,
                line_y,
                display_line,
            )


# ══════════════════════════════════════════════════════════════
# الخلايا
# ══════════════════════════════════════════════════════════════

def draw_border(
    c,
    x,
    y,
    w,
    h,
    width=0.5,
):
    c.setStrokeColor(C_BLACK)
    c.setLineWidth(width)

    c.rect(
        x,
        y,
        w,
        h,
        fill=0,
        stroke=1,
    )

    c.setLineWidth(0.5)


def draw_rounded_top(
    c,
    x,
    y,
    w,
    h,
    radius=RADIUS,
    width=0.5,
):
    c.setFillColor(C_PRIMARY)
    c.setStrokeColor(C_BLACK)
    c.setLineWidth(width)

    p = c.beginPath()

    p.moveTo(x, y)

    p.lineTo(
        x,
        y + h - radius,
    )

    p.arcTo(
        x,
        y + h - 2 * radius,
        x + 2 * radius,
        y + h,
        180,
        -90,
    )

    p.lineTo(
        x + w - radius,
        y + h,
    )

    p.arcTo(
        x + w - 2 * radius,
        y + h - 2 * radius,
        x + w,
        y + h,
        90,
        -90,
    )

    p.lineTo(
        x + w,
        y,
    )

    p.close()

    c.drawPath(
        p,
        fill=1,
        stroke=1,
    )

    c.setLineWidth(0.5)


def draw_section_title(
    c,
    x,
    y,
    w,
    h,
    text,
):
    draw_rounded_top(
        c,
        x,
        y,
        w,
        h,
    )

    c.setFillColor(C_WHITE)

    draw_wrapped_text(
        c,
        x,
        y,
        w,
        h,
        text,
        font_name="Naskh-Bold",
        font_size=10,
        min_size=8,
        color=C_WHITE,
    )


def draw_label(
    c,
    x,
    y,
    w,
    h,
    text,
    size=8,
    bg=C_PRIMARY,
    color=C_WHITE,
):
    c.setFillColor(bg)

    c.rect(
        x,
        y,
        w,
        h,
        fill=1,
        stroke=0,
    )

    draw_border(
        c,
        x,
        y,
        w,
        h,
    )

    draw_wrapped_text(
        c,
        x,
        y,
        w,
        h,
        text,
        font_name="Naskh-Bold",
        font_size=size,
        min_size=max(size - 1.5, 5.5),
        color=color,
    )


def draw_value(
    c,
    x,
    y,
    w,
    h,
    text,
    size=8,
    bg=None,
    border=True,
    align="center",
):
    if bg:
        c.setFillColor(bg)

        c.rect(
            x,
            y,
            w,
            h,
            fill=1,
            stroke=0,
        )

    if border:
        draw_border(
            c,
            x,
            y,
            w,
            h,
        )

    draw_wrapped_text(
        c,
        x,
        y,
        w,
        h,
        text,
        font_name="Naskh",
        font_size=size,
        min_size=max(size - 1.25, PDF_FONT_MIN),
        color=C_BLACK,
        align=align,
    )


def draw_paragraph(
    c,
    x,
    y,
    w,
    h,
    text,
    size=8,
    bg=None,
    border=True,
    align="right",
):
    if bg:
        c.setFillColor(bg)

        c.rect(
            x,
            y,
            w,
            h,
            fill=1,
            stroke=0,
        )

    if border:
        draw_border(
            c,
            x,
            y,
            w,
            h,
        )

    draw_wrapped_text(
        c,
        x,
        y,
        w,
        h,
        text,
        font_name="Naskh",
        font_size=size,
        min_size=max(size - 1.5, 5.5),
        color=C_BLACK,
        align=align,
    )


# ══════════════════════════════════════════════════════════════
# ارتفاع الصف الذكي
# ══════════════════════════════════════════════════════════════

def smart_row_height(
    values,
    widths,
    base_height,
    font_size=8,
    min_size=7,
    max_extra=0.22 * cm,
):
    """
    يزيد ارتفاع الصف قليلًا إذا احتاج النص للالتفاف.
    لا يسمح بزيادة كبيرة.
    """

    max_lines = 1

    for value, width in zip(values, widths):
        if not value:
            continue

        lines = wrap_text(
            str(value),
            "Naskh",
            font_size,
            max(width - 8, 10),
        )

        max_lines = max(
            max_lines,
            len(lines),
        )

    if max_lines <= 1:
        return base_height

    calculated = (
        max_lines
        * font_size
        * 1.15
        + 6
    )

    height = max(
        base_height,
        calculated,
    )

    return min(
        height,
        base_height + max_extra,
    )


# ══════════════════════════════════════════════════════════════
# الأرقام
# ══════════════════════════════════════════════════════════════

def parse_number(value):
    """تحويل القيمة النصية إلى رقم."""
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    # الأرقام العربية
    translation = str.maketrans(
        "٠١٢٣٤٥٦٧٨٩٫٬",
        "0123456789.,",
    )

    text = text.translate(translation)

    text = text.replace(",", "")

    match = re.search(
        r"-?\d+(?:\.\d+)?",
        text,
    )

    if not match:
        return None

    try:
        return float(match.group())
    except ValueError:
        return None


def clean_number(value):
    """إزالة .0 من الرقم عند الحاجة."""
    number = parse_number(value)

    if number is None:
        return str(value or "")

    if number.is_integer():
        return str(int(number))

    return f"{number:g}"


def area_value(value):
    if value is None:
        return ""

    text = str(value).strip()

    if not text:
        return ""

    text = re.sub(
        r"\s*(م²|م2|متر مربع|متر|م)\s*$",
        "",
        text,
        flags=re.IGNORECASE,
    )

    clean = clean_number(text)

    return f"{clean} م2"

# ══════════════════════════════════════════════════════════════
# الإحداثيات وQR
# ══════════════════════════════════════════════════════════════

def extract_coordinates(data):
    """
    استخراج جميع نقاط E/N الموجودة.
    """

    points = {}

    for key, value in data.items():
        match_e = re.match(
            r"^الإحداثي الشرقي \(E\) (\d+)$",
            key,
        )

        match_n = re.match(
            r"^الإحداثي الشمالي \(N\) (\d+)$",
            key,
        )

        if match_e:
            index = int(match_e.group(1))
            number = parse_number(value)

            if number is not None:
                points.setdefault(
                    index,
                    {},
                )["e"] = number

        elif match_n:
            index = int(match_n.group(1))
            number = parse_number(value)

            if number is not None:
                points.setdefault(
                    index,
                    {},
                )["n"] = number

    result = []

    for index in sorted(points):
        point = points[index]

        if (
            "e" in point
            and "n" in point
        ):
            result.append(
                (
                    point["e"],
                    point["n"],
                )
            )

    return result


def calculate_average_coordinate(data):
    """حساب متوسط E وN."""

    points = extract_coordinates(data)

    if not points:
        return None, None

    average_e = (
        sum(
            e
            for e, n in points
        )
        / len(points)
    )

    average_n = (
        sum(
            n
            for e, n in points
        )
        / len(points)
    )

    return average_e, average_n


def get_utm_zone(data):
    """استخراج Zone من البيانات."""
    value = data.get(
        "النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي",
        "",
    )

    match = re.search(
        r"(\d{1,2})",
        str(value),
    )

    if match:
        zone = int(match.group(1))

        if 1 <= zone <= 60:
            return zone

    return 38


def utm_to_google_coordinates(
    easting,
    northing,
    zone,
):
    """
    تحويل UTM إلى WGS84.
    """

    if Transformer is None:
        return None, None

    try:
        transformer = Transformer.from_crs(
            f"EPSG:{32600 + zone}",
            "EPSG:4326",
            always_xy=True,
        )

        longitude, latitude = transformer.transform(
            easting,
            northing,
        )

        return latitude, longitude

    except Exception:
        return None, None


def create_google_maps_url(data):
    """
    إنشاء رابط Google Maps من متوسط الإحداثيات.
    """

    average_e, average_n = calculate_average_coordinate(
        data
    )

    if average_e is None or average_n is None:
        return None

    zone = get_utm_zone(data)

    latitude, longitude = utm_to_google_coordinates(
        average_e,
        average_n,
        zone,
    )

    if latitude is None or longitude is None:
        return None

    return (
        "https://www.google.com/maps/search/?api=1"
        f"&query={latitude:.8f},{longitude:.8f}"
    )


def generate_qr(data, path):
    """
    إنشاء QR يفتح نقطة متوسط الإحداثيات في Google Maps.
    """

    try:
        import qrcode
    except ImportError:
        return False

    url = create_google_maps_url(data)

    if not url:
        return False

    try:
        qr = qrcode.make(url)
        qr.save(path)
        return True

    except Exception:
        return False


# ══════════════════════════════════════════════════════════════
# إنشاء PDF
# ══════════════════════════════════════════════════════════════

def extract_owners(data):
    """استخراج قائمة الملاك من البيانات."""
    owners = []

    raw_owners = data.get("ملاك العقار")
    if isinstance(raw_owners, list):
        for o in raw_owners:
            if isinstance(o, dict):
                name = str(o.get("اسم المالك", o.get("name", ""))).strip()
                oid = str(o.get("رقم الهوية", o.get("id", ""))).strip()
                if name or oid:
                    owners.append({"name": name, "id": oid})
            elif isinstance(o, str) and o.strip():
                owners.append({"name": o.strip(), "id": ""})

    if not owners:
        for i in range(1, 100):
            name = str(data.get(f"اسم المالك {i}", "")).strip()
            oid = str(data.get(f"رقم الهوية {i}", "")).strip()
            if not name and not oid:
                if i > 2:
                    break
                continue
            owners.append({"name": name, "id": oid})

    if not owners:
        name = str(data.get("اسم المالك", "")).strip()
        oid = str(data.get("رقم الهوية", "")).strip()
        if name or oid:
            owners.append({"name": name, "id": oid})

    return owners


def generate_pdf(
    data,
    output_path=None,
    main_title=None,
    company_title=None,
    aerial_image=None,
):
    """توليد ملف PDF وحفظه."""
    register_fonts()

    if not output_path:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        order_no = str(
            data.get("رقم الطلب", "")
            or data.get("رقم_الطلب", "")
            or data.get("application_number", "")
        ).strip()
        safe_order_no = re.sub(r'[\\/*?:"<>|\r\n\t]', '', order_no).strip()

        if safe_order_no:
            filename = f"{safe_order_no}.pdf"
        else:
            filename = f"تقرير_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        output_path = os.path.join(
            OUTPUT_DIR,
            filename,
        )

    title_text = (
        main_title
        or DEFAULT_MAIN_TITLE
    )
    company_text = (
        company_title
        or DEFAULT_COMPANY_TITLE
    )

    c = canvas.Canvas(
        output_path,
        pagesize=A4,
    )
    c.setTitle(title_text)

    # ══════════════════════════════════════════════════════
    # الشبكة
    # ══════════════════════════════════════════════════════

    x = MARGIN
    cw = CONTENT_W
    col_w = cw / 10

    def colx(number):
        return x + (number - 1) * col_w

    H_HEADER = 2.2 * cm
    H_SECTION = 0.52 * cm
    H_ROW = 0.48 * cm
    H_COORD = 0.40 * cm
    H_2ROWS = H_ROW * 2

    company_lines = company_text.splitlines()
    line_spacing = 9.5
    n_footer = len(company_lines)

    footer_bottom_y = MARGIN + 4
    footer_start_y = footer_bottom_y + max(n_footer - 1, 0) * line_spacing
    frame_bottom = footer_start_y + 8 + 0.20 * cm

    owners = extract_owners(data)
    n_owners = max(len(owners), 1)
    owner_rows = n_owners if n_owners <= 3 else (n_owners + 1) // 2

    two_pages = (owner_rows > MAX_OWNERS_1PAGE)

    def draw_header_bar(curr_y):
        header_y = curr_y - H_HEADER

        # QR - الطرف الأيمن
        qr_w = col_w * 3
        qr_x = x + cw - qr_w
        qr_path = None
        try:
            if os.path.exists(LOGO_QR):
                qr_path = LOGO_QR
            else:
                temp_qr = os.path.join(
                    OUTPUT_DIR,
                    "_qr_temp.png",
                )
                if generate_qr(
                    data,
                    temp_qr,
                ):
                    qr_path = temp_qr

            if qr_path and os.path.exists(qr_path):
                c.drawImage(
                    qr_path,
                    qr_x,
                    header_y + 0.1 * cm,
                    width=qr_w,
                    height=H_HEADER - 0.2 * cm,
                    preserveAspectRatio=True,
                    anchor="e",
                    mask="auto",
                )
        except Exception:
            pass

        # العنوان
        title_x = colx(4)
        title_w = col_w * 4

        c.setFillColor(C_PRIMARY)
        c.setFont(
            "Naskh-Bold",
            20,
        )
        c.drawCentredString(
            title_x + title_w / 2,
            header_y + H_HEADER / 2 + 3,
            ar(title_text),
        )

        c.setFillColor(C_SECONDARY)
        c.setFont(
            "Naskh",
            11,
        )
        c.drawCentredString(
            title_x + title_w / 2,
            header_y + H_HEADER / 2 - 18,
            ar("لغرض تحديث / تعديل صك"),
        )

        # RER - الطرف الأيسر
        rer_x = x
        rer_w = col_w * 3
        if os.path.exists(LOGO_RER):
            try:
                c.drawImage(
                    LOGO_RER,
                    rer_x,
                    header_y + 0.1 * cm,
                    width=rer_w,
                    height=H_HEADER - 0.2 * cm,
                    preserveAspectRatio=True,
                    anchor="w",
                    mask="auto",
                )
            except Exception:
                pass

        return header_y

    def draw_footer_bar(page_num, total_pages):
        c.setFillColor(C_COMPANY)
        c.setFont("Naskh", 8)
        for index, line in enumerate(company_lines):
            c.drawCentredString(
                x + cw / 2,
                footer_start_y - index * line_spacing,
                ar(line),
            )
        if total_pages > 1:
            c.setFont("Naskh", 7)
            c.setFillColor(colors.HexColor("#777777"))
            c.drawString(
                x,
                footer_bottom_y,
                ar(f"صفحة {page_num} من {total_pages}"),
            )

    # ══════════════════════════════════════════════════════
    # الصفحة الأولى
    # ══════════════════════════════════════════════════════

    y = PAGE_H - MARGIN
    y = draw_header_bar(y)

    # ══════════════════════════════════════════════════════
    # معلومات التقرير
    # ══════════════════════════════════════════════════════

    y -= H_SECTION
    draw_section_title(
        c,
        x,
        y,
        cw,
        H_SECTION,
        "معلومات التقرير",
    )

    report_date = datetime.now().strftime(
        "%Y-%m-%d"
    )

    report_date = datetime.now().strftime(
        "%Y-%m-%d"
    )
    report_num = str(
        data.get("رقم التقرير", "")
        or data.get("report_number", "")
    ).strip() or report_date

    fixed_rows = [
        (
            report_date,
            "تاريخ التقرير",
            report_num,
            "رقم التقرير",
        ),
        (
            data.get(
                "تاريخ الصك",
                "",
            ),
            "تاريخ الصك",
            data.get(
                "رقم صك وزارة العدل",
                "",
            ),
            "رقم صك وزارة العدل",
        ),
    ]

    for (
        value_a,
        label_a,
        value_b,
        label_b,
    ) in fixed_rows:
        row_height = smart_row_height(
            [
                value_a,
                value_b,
            ],
            [
                col_w * 2,
                col_w * 5,
            ],
            H_ROW,
            font_size=8,
            min_size=7,
        )
        y -= row_height
        draw_value(
            c,
            colx(1),
            y,
            col_w * 2,
            row_height,
            value_a,
            size=8,
        )
        draw_label(
            c,
            colx(3),
            y,
            col_w,
            row_height,
            label_a,
            size=8,
        )
        draw_value(
            c,
            colx(4),
            y,
            col_w * 5,
            row_height,
            value_b,
            size=8,
        )
        draw_label(
            c,
            colx(9),
            y,
            col_w * 2,
            row_height,
            label_b,
            size=7,
        )

    # ══════════════════════════════════════════════════════
    # جدول الملاك
    # ══════════════════════════════════════════════════════

    # فاصل مستقل عن البيانات التي فوقه
    y -= 0.20 * cm

    if not owners:
        owners = [{"name": data.get("اسم المالك", ""), "id": data.get("رقم الهوية", "")}]

    if len(owners) <= 3:
        # جدول من عمودين على رأسه: اسم المالك (يمين) ورقم الهوية (يسار)
        y -= H_ROW
        draw_label(
            c,
            colx(4),
            y,
            col_w * 7,
            H_ROW,
            "اسم المالك",
            size=8,
        )
        draw_label(
            c,
            colx(1),
            y,
            col_w * 3,
            H_ROW,
            "رقم الهوية",
            size=8,
        )

        for owner in owners:
            owner_name = owner.get("name", "")
            owner_id = owner.get("id", "")
            o_h = smart_row_height(
                [
                    owner_id,
                    owner_name,
                ],
                [
                    col_w * 3,
                    col_w * 7,
                ],
                H_ROW,
                font_size=8,
                min_size=7,
            )
            y -= o_h
            draw_value(
                c,
                colx(4),
                y,
                col_w * 7,
                o_h,
                owner_name,
                size=8,
            )
            draw_value(
                c,
                colx(1),
                y,
                col_w * 3,
                o_h,
                owner_id,
                size=8,
            )
    else:
        # أكثر من 3 ملاك: جدول مقسوم إلى نصفين متجاورين مع فاصل صغير بينهما
        # نصف أيمن: [اسم المالك] [رقم الهوية] | فاصل | نصف أيسر: [اسم المالك] [رقم الهوية]
        gap = 0.10 * cm
        w_avail = cw - gap
        w_section = w_avail / 2.0
        w_name = w_section * 0.60
        w_id = w_section - w_name

        # إحداثيات النصف الأيسر (من الهامش الأيسر x إلى x + w_section)
        x_id_l = x
        x_name_l = x + w_id

        # إحداثيات النصف الأيمن (من x + w_section + gap إلى x + cw)
        x_id_r = x + w_section + gap
        x_name_r = x_id_r + w_id

        y -= H_ROW

        # رؤوس النصف الأيمن
        draw_label(
            c,
            x_name_r,
            y,
            w_name,
            H_ROW,
            "اسم المالك",
            size=8,
        )
        draw_label(
            c,
            x_id_r,
            y,
            w_id,
            H_ROW,
            "رقم الهوية",
            size=8,
        )

        # رؤوس النصف الأيسر
        draw_label(
            c,
            x_name_l,
            y,
            w_name,
            H_ROW,
            "اسم المالك",
            size=8,
        )
        draw_label(
            c,
            x_id_l,
            y,
            w_id,
            H_ROW,
            "رقم الهوية",
            size=8,
        )

        num_rows = (len(owners) + 1) // 2
        for r in range(num_rows):
            owner_r = owners[2 * r]
            owner_l = owners[2 * r + 1] if (2 * r + 1) < len(owners) else None

            name_r = owner_r.get("name", "")
            id_r = owner_r.get("id", "")
            name_l = owner_l.get("name", "") if owner_l else ""
            id_l = owner_l.get("id", "") if owner_l else ""

            o_h = smart_row_height(
                [
                    id_l,
                    name_l,
                    id_r,
                    name_r,
                ],
                [
                    w_id,
                    w_name,
                    w_id,
                    w_name,
                ],
                H_ROW,
                font_size=8,
                min_size=7,
            )
            y -= o_h

            # النصف الأيمن
            draw_value(
                c,
                x_name_r,
                y,
                w_name,
                o_h,
                name_r,
                size=8,
            )
            draw_value(
                c,
                x_id_r,
                y,
                w_id,
                o_h,
                id_r,
                size=8,
            )

            # النصف الأيسر
            draw_value(
                c,
                x_name_l,
                y,
                w_name,
                o_h,
                name_l,
                size=8,
            )
            draw_value(
                c,
                x_id_l,
                y,
                w_id,
                o_h,
                id_l,
                size=8,
            )

    # فاصل بسيط ونظيف بين الأقسام
    y -= 0.15 * cm

    # ══════════════════════════════════════════════════════
    # معلومات العقار
    # ══════════════════════════════════════════════════════

    y -= H_SECTION

    draw_section_title(
        c,
        x,
        y,
        cw,
        H_SECTION,
        "معلومات العقار",
    )

    # صف العناوين
    y -= H_ROW

    labels = [
        (1, 2, "المدينة", 7),
        (3, 1, "اسم الحي", 7),
        (4, 1, "رقم البلوك", 7),
        (5, 1, "رقم المخطط", 7),
        (6, 1, "رقم القطعة بالمخطط", 6),
        (7, 4, "رقم العقار في طبقة الأراضي", 7),
    ]

    for col, width, text, size in labels:
        draw_label(
            c,
            colx(col),
            y,
            col_w * width,
            H_ROW,
            text,
            size=size,
        )

    # صف القيم
    property_values = [
        data.get(
            "اسم المدينة",
            "",
        )
        or data.get(
            "المنطقة",
            "",
        ),
        data.get(
            "اسم الحي",
            "",
        ),
        data.get(
            "رقم البلوك",
            "",
        ),
        data.get(
            "رقم المخطط",
            "",
        ),
        data.get(
            "رقم القطعة بالمخطط",
            "",
        ),
        clean_number(
            data.get(
                "رقم العقار في طبقة الأراضي",
                data.get(
                    "رقم السجل العقاري",
                    "",
                ),
            )
        ),
    ]

    widths = [
        col_w * 2,
        col_w,
        col_w,
        col_w,
        col_w,
        col_w * 4,
    ]

    property_height = smart_row_height(
        property_values,
        widths,
        H_ROW,
        font_size=8,
        min_size=7,
    )

    y -= property_height

    positions = [
        (1, 2),
        (3, 1),
        (4, 1),
        (5, 1),
        (6, 1),
        (7, 4),
    ]

    for (
        (col, width),
        value,
    ) in zip(
        positions,
        property_values,
    ):
        draw_value(
            c,
            colx(col),
            y,
            col_w * width,
            property_height,
            value,
            size=7,
        )


    # ══════════════════════════════════════════════════════
    # الوصف والحدود
    # ══════════════════════════════════════════════════════

    y_two = y - H_2ROWS
    h_two = H_2ROWS

    draw_paragraph(
        c,
        colx(1),
        y_two,
        col_w * 4,
        h_two,
        data.get(
            "وصف العقار",
            "",
        ),
        size=9,
    )

    draw_label(
        c,
        colx(5),
        y_two,
        col_w * 2,
        h_two,
        "وصف العقار",
        size=8,
    )

    # حدود طبقة الأراضي
    draw_value(
        c,
        colx(7),
        y_two + H_ROW,
        col_w * 2,
        H_ROW,
        area_value(
            data.get(
                "الحدود حسب طبقة الأراضي",
                "",
            )
        ),
        size=8,
    )

    # حدود الصك
    draw_value(
        c,
        colx(7),
        y_two,
        col_w * 2,
        H_ROW,
        area_value(
            data.get(
                "الحدود حسب الصك",
                "",
            )
        ),
        size=8,
    )

    draw_label(
        c,
        colx(9),
        y_two + H_ROW,
        col_w,
        H_ROW,
        "حسب طبقة الأراضي",
        size=6,
        bg=C_WHITE,
        color=C_BLACK,
    )

    draw_label(
        c,
        colx(9),
        y_two,
        col_w,
        H_ROW,
        "حسب الصك",
        size=7,
        bg=C_WHITE,
        color=C_BLACK,
    )

    draw_label(
        c,
        colx(10),
        y_two,
        col_w,
        h_two,
        "مساحة العقار",
        size=7,
    )

    y = y_two

    # ══════════════════════════════════════════════════════
    # رؤوس الأبعاد
    # ══════════════════════════════════════════════════════

    y -= H_ROW

    draw_label(
        c,
        colx(1),
        y,
        col_w * 2,
        H_ROW,
        "الأبعاد حسب الطبيعة*",
        size=7,
    )

    draw_label(
        c,
        colx(3),
        y,
        col_w * 2,
        H_ROW,
        "الأبعاد حسب الصك",
        size=7,
    )

    y -= H_ROW

    draw_label(
        c,
        colx(1),
        y,
        col_w,
        H_ROW,
        "المجموع",
        size=6,
    )

    draw_label(
        c,
        colx(2),
        y,
        col_w,
        H_ROW,
        "طول الضلع",
        size=6,
    )

    draw_label(
        c,
        colx(3),
        y,
        col_w,
        H_ROW,
        "المجموع",
        size=6,
    )

    draw_label(
        c,
        colx(4),
        y,
        col_w,
        H_ROW,
        "طول الضلع",
        size=6,
    )

    merged_y = y
    merged_h = H_2ROWS

    # الطبيعة
    c.setFillColor(C_PRIMARY)
    c.rect(
        colx(5),
        merged_y,
        col_w * 2,
        merged_h,
        fill=1,
        stroke=0,
    )

    draw_border(
        c,
        colx(5),
        merged_y,
        col_w * 2,
        merged_h,
    )

    draw_wrapped_text(
        c,
        colx(5),
        merged_y,
        col_w * 2,
        merged_h,
        "الحدود حسب الطبيعة",
        font_name="Naskh-Bold",
        font_size=8,
        min_size=7,
        color=C_WHITE,
    )

    # الصك
    c.setFillColor(C_PRIMARY)
    c.rect(
        colx(7),
        merged_y,
        col_w * 2,
        merged_h,
        fill=1,
        stroke=0,
    )

    draw_border(
        c,
        colx(7),
        merged_y,
        col_w * 2,
        merged_h,
    )

    draw_wrapped_text(
        c,
        colx(7),
        merged_y,
        col_w * 2,
        merged_h,
        "الحدود حسب الصك",
        font_name="Naskh-Bold",
        font_size=8,
        min_size=7,
        color=C_WHITE,
    )

    # الاتجاه
    c.setFillColor(C_PRIMARY)
    c.rect(
        colx(9),
        merged_y,
        col_w * 2,
        merged_h,
        fill=1,
        stroke=0,
    )

    draw_border(
        c,
        colx(9),
        merged_y,
        col_w * 2,
        merged_h,
    )

    draw_wrapped_text(
        c,
        colx(9),
        merged_y,
        col_w * 2,
        merged_h,
        "الإتجاه",
        font_name="Naskh-Bold",
        font_size=8,
        min_size=7,
        color=C_WHITE,
    )

    # ══════════════════════════════════════════════════════
    # الأبعاد
    # ══════════════════════════════════════════════════════

    directions = [
        ("شمال", "أ"),
        ("جنوب", "ب"),
        ("شرق", "ج"),
        ("غرب", "د"),
    ]

    for index, (
        direction,
        letter,
    ) in enumerate(
        directions,
        start=1,
    ):

        land_total = data.get(
            f"الأبعاد حسب طبقة الأراضي (المجموع) {index}",
            "",
        )

        land_side = data.get(
            f"الأبعاد حسب طبقة الأراضي (طول الضلع) {index}",
            "",
        )

        deed_total = data.get(
            f"الأبعاد حسب الصك (المجموع) {index}",
            "",
        )

        deed_side = data.get(
            f"الأبعاد حسب الصك (طول الضلع) {index}",
            "",
        )

        nature = data.get(
            f"الحدود حسب الطبيعة {index}",
            "",
        )

        deed = data.get(
            f"الحدود حسب الصك {index}",
            "",
        )

        values = [
            f"{land_total} متر" if land_total else "",
            f"{land_side} متر" if land_side else "",
            f"{deed_total} متر" if deed_total else "",
            f"{deed_side} متر" if deed_side else "",
            nature,
            deed,
        ]

        widths = [
            col_w,
            col_w,
            col_w,
            col_w,
            col_w * 2,
            col_w * 2,
        ]

        row_height = smart_row_height(
            values,
            widths,
            H_ROW,
            font_size=7,
            min_size=6.5,
            max_extra=0.35 * cm,
        )

        y -= row_height

        draw_value(
            c,
            colx(1),
            y,
            col_w,
            row_height,
            values[0],
            size=7,
        )

        draw_value(
            c,
            colx(2),
            y,
            col_w,
            row_height,
            values[1],
            size=7,
        )

        draw_value(
            c,
            colx(3),
            y,
            col_w,
            row_height,
            values[2],
            size=7,
        )

        draw_value(
            c,
            colx(4),
            y,
            col_w,
            row_height,
            values[3],
            size=7,
        )

        draw_value(
            c,
            colx(5),
            y,
            col_w * 2,
            row_height,
            values[4],
            size=7,
            align="right",
        )

        draw_value(
            c,
            colx(7),
            y,
            col_w * 2,
            row_height,
            values[5],
            size=7,
            align="right",
        )

        draw_value(
            c,
            colx(9),
            y,
            col_w,
            row_height,
            direction,
            size=8,
        )

        draw_value(
            c,
            colx(10),
            y,
            col_w,
            row_height,
            letter,
            size=8,
        )

    # ══════════════════════════════════════════════════════
    # المادة 13
    # ══════════════════════════════════════════════════════

    y -= H_ROW

    draw_paragraph(
        c,
        x,
        y,
        cw,
        H_ROW,
        "المساحة والأطوال بحسب طبقة الأراضي قد تختلف وفق لما ورد "
        "في المادة الثالثة عشر من اللائحة التنفيذية لنظام التسجيل "
        "العيني للعقار",
        size=7,
        bg=C_WHITE,
        border=True,
    )

    # ══════════════════════════════════════════════════════
    # الإحداثيات
    # ══════════════════════════════════════════════════════

    # استخراج الإحداثيات وترتيبها
    coordinate_indices = set()

    for key in data:
        match = re.match(
            r"^الإحداثي (الشمالي \(N\)|الشرقي \(E\)) (\d+)$",
            key,
        )

        if match:
            coordinate_indices.add(
                int(match.group(2))
            )

    sorted_indices = (
        sorted(coordinate_indices)
        if coordinate_indices
        else [1, 2, 3, 4]
    )

    if len(sorted_indices) > 6:
        # تقسيم الإحداثيات إلى عمودين إذا زادت عن 6 نقاط
        y -= H_COORD * 2

        # شرق (يسار الجدول 2)
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(1),
            y,
            col_w * 2,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )
        draw_border(
            c,
            colx(1),
            y,
            col_w * 2,
            H_COORD * 2,
        )
        draw_wrapped_text(
            c,
            colx(1),
            y,
            col_w * 2,
            H_COORD * 2,
            "الاحداثي شرق (E)",
            font_name="Naskh-Bold",
            font_size=7,
            min_size=6,
            color=C_WHITE,
        )

        # شمال (وسط الجدول 2)
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(3),
            y,
            col_w * 2,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )
        draw_border(
            c,
            colx(3),
            y,
            col_w * 2,
            H_COORD * 2,
        )
        draw_wrapped_text(
            c,
            colx(3),
            y,
            col_w * 2,
            H_COORD * 2,
            "الاحداثي شمال (N)",
            font_name="Naskh-Bold",
            font_size=7,
            min_size=6,
            color=C_WHITE,
        )

        # الرقم (يمين الجدول 2)
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(5),
            y,
            col_w,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )
        draw_border(
            c,
            colx(5),
            y,
            col_w,
            H_COORD * 2,
        )
        draw_wrapped_text(
            c,
            colx(5),
            y,
            col_w,
            H_COORD * 2,
            "الإحداثيات",
            font_name="Naskh-Bold",
            font_size=7,
            min_size=6,
            color=C_WHITE,
        )

        # شرق (يسار الجدول 1)
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(6),
            y,
            col_w * 2,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )
        draw_border(
            c,
            colx(6),
            y,
            col_w * 2,
            H_COORD * 2,
        )
        draw_wrapped_text(
            c,
            colx(6),
            y,
            col_w * 2,
            H_COORD * 2,
            "الاحداثي شرق (E)",
            font_name="Naskh-Bold",
            font_size=7,
            min_size=6,
            color=C_WHITE,
        )

        # شمال (وسط الجدول 1)
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(8),
            y,
            col_w * 2,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )
        draw_border(
            c,
            colx(8),
            y,
            col_w * 2,
            H_COORD * 2,
        )
        draw_wrapped_text(
            c,
            colx(8),
            y,
            col_w * 2,
            H_COORD * 2,
            "الاحداثي شمال (N)",
            font_name="Naskh-Bold",
            font_size=7,
            min_size=6,
            color=C_WHITE,
        )

        # الرقم (يمين الجدول 1)
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(10),
            y,
            col_w,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )
        draw_border(
            c,
            colx(10),
            y,
            col_w,
            H_COORD * 2,
        )
        draw_wrapped_text(
            c,
            colx(10),
            y,
            col_w,
            H_COORD * 2,
            "الإحداثيات",
            font_name="Naskh-Bold",
            font_size=7,
            min_size=6,
            color=C_WHITE,
        )

        mid = (len(sorted_indices) + 1) // 2
        table_a = sorted_indices[:mid]
        table_b = sorted_indices[mid:]

        for i in range(mid):
            y -= H_COORD
            idx_a = table_a[i]

            # الجدول الأيمن
            draw_value(
                c,
                colx(10),
                y,
                col_w,
                H_COORD,
                str(idx_a),
                size=7,
            )
            draw_value(
                c,
                colx(8),
                y,
                col_w * 2,
                H_COORD,
                data.get(
                    f"الإحداثي الشمالي (N) {idx_a}",
                    "",
                ),
                size=7,
            )
            draw_value(
                c,
                colx(6),
                y,
                col_w * 2,
                H_COORD,
                data.get(
                    f"الإحداثي الشرقي (E) {idx_a}",
                    "",
                ),
                size=7,
            )

            # الجدول الأيسر
            if i < len(table_b):
                idx_b = table_b[i]
                draw_value(
                    c,
                    colx(5),
                    y,
                    col_w,
                    H_COORD,
                    str(idx_b),
                    size=7,
                )
                draw_value(
                    c,
                    colx(3),
                    y,
                    col_w * 2,
                    H_COORD,
                    data.get(
                        f"الإحداثي الشمالي (N) {idx_b}",
                        "",
                    ),
                    size=7,
                )
                draw_value(
                    c,
                    colx(1),
                    y,
                    col_w * 2,
                    H_COORD,
                    data.get(
                        f"الإحداثي الشرقي (E) {idx_b}",
                        "",
                    ),
                    size=7,
                )
            else:
                draw_value(
                    c,
                    colx(5),
                    y,
                    col_w,
                    H_COORD,
                    "",
                    size=7,
                )
                draw_value(
                    c,
                    colx(3),
                    y,
                    col_w * 2,
                    H_COORD,
                    "",
                    size=7,
                )
                draw_value(
                    c,
                    colx(1),
                    y,
                    col_w * 2,
                    H_COORD,
                    "",
                    size=7,
                )

    else:
        # الوضع العادي (6 نقاط أو أقل)
        y -= H_COORD * 2

        # شرق
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(1),
            y,
            col_w * 4,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )

        draw_border(
            c,
            colx(1),
            y,
            col_w * 4,
            H_COORD * 2,
        )

        draw_wrapped_text(
            c,
            colx(1),
            y,
            col_w * 4,
            H_COORD * 2,
            "الاحداثي شرق (E)",
            font_name="Naskh-Bold",
            font_size=8,
            min_size=7,
            color=C_WHITE,
        )

        # شمال
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(5),
            y,
            col_w * 4,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )

        draw_border(
            c,
            colx(5),
            y,
            col_w * 4,
            H_COORD * 2,
        )

        draw_wrapped_text(
            c,
            colx(5),
            y,
            col_w * 4,
            H_COORD * 2,
            "الاحداثي شمال (N)",
            font_name="Naskh-Bold",
            font_size=8,
            min_size=7,
            color=C_WHITE,
        )

        # الرقم
        c.setFillColor(C_PRIMARY)
        c.rect(
            colx(9),
            y,
            col_w * 2,
            H_COORD * 2,
            fill=1,
            stroke=0,
        )

        draw_border(
            c,
            colx(9),
            y,
            col_w * 2,
            H_COORD * 2,
        )

        draw_wrapped_text(
            c,
            colx(9),
            y,
            col_w * 2,
            H_COORD * 2,
            "الإحداثيات",
            font_name="Naskh-Bold",
            font_size=8,
            min_size=7,
            color=C_WHITE,
        )

        for index in sorted_indices:
            y -= H_COORD

            draw_value(
                c,
                colx(1),
                y,
                col_w * 4,
                H_COORD,
                data.get(
                    f"الإحداثي الشرقي (E) {index}",
                    "",
                ),
                size=7,
            )

            draw_value(
                c,
                colx(5),
                y,
                col_w * 4,
                H_COORD,
                data.get(
                    f"الإحداثي الشمالي (N) {index}",
                    "",
                ),
                size=7,
            )

            draw_value(
                c,
                colx(9),
                y,
                col_w * 2,
                H_COORD,
                str(index),
                size=7,
            )

    # ══════════════════════════════════════════════════════
    # SANSRS
    # ══════════════════════════════════════════════════════

    y -= H_ROW * 1.5

    draw_paragraph(
        c,
        colx(1),
        y,
        col_w * 5,
        H_ROW * 1.5,
        "Note: All coordinates are in National Geodetic Reference "
        "Frame KSA-GRF17 as per Saudi Arabia National Spatial "
        "Reference System (SANSRS)",
        size=6,
    )

    draw_paragraph(
        c,
        colx(6),
        y,
        col_w * 5,
        H_ROW * 1.5,
        "ملاحظة: جميع الاحداثيات بإطار المرجع الجيوديسي الوطني "
        "KSA-GRF17 بحسب المرجع المكاني الوطني للمملكة SANSRS",
        size=6,
    )

    # ══════════════════════════════════════════════════════
    # UTM Zone
    # ══════════════════════════════════════════════════════

    y -= H_ROW

    zone = get_utm_zone(data)

    draw_value(
        c,
        colx(1),
        y,
        col_w * 3,
        H_ROW,
        "Universal Transverse Mercator (UTM) Zone:",
        size=7,
    )

    draw_value(
        c,
        colx(4),
        y,
        col_w * 4,
        H_ROW,
        f"{zone} N",
        size=8,
    )

    draw_value(
        c,
        colx(8),
        y,
        col_w * 3,
        H_ROW,
        "النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي",
        size=6,
    )


    if two_pages:
        # نهاية الصفحة الأولى
        draw_footer_bar(1, 2)
        c.showPage()

        # ══════════════════════════════════════════════════════
        # الصفحة الثانية: الإسقاط المساحي
        # ══════════════════════════════════════════════════════
        y2 = PAGE_H - MARGIN
        y2 = draw_header_bar(y2)

        y2 -= H_ROW + H_SECTION
        draw_section_title(
            c,
            x,
            y2,
            cw,
            H_SECTION,
            "الإسقاط المساحي",
        )

        orig_map_h = 12.02 * cm
        p2_frame_top = y2 - 0.08 * cm
        p2_frame_height = min(orig_map_h, p2_frame_top - frame_bottom)
        p2_frame_bottom = p2_frame_top - p2_frame_height

        if p2_frame_height > 0.5 * cm:
            image_margin = 0.15 * cm
            image_x = x + image_margin
            image_y = p2_frame_bottom + image_margin
            image_w = cw - image_margin * 2
            image_h = p2_frame_height - image_margin * 2

            c.setFillColor(C_LIGHT)
            c.rect(
                x,
                p2_frame_bottom,
                cw,
                p2_frame_height,
                fill=1,
                stroke=0,
            )
            draw_border(
                c,
                x,
                p2_frame_bottom,
                cw,
                p2_frame_height,
                width=0.7,
            )

            if aerial_image and os.path.exists(aerial_image):
                try:
                    img = ImageReader(aerial_image)
                    c.drawImage(
                        img,
                        image_x,
                        image_y,
                        width=image_w,
                        height=image_h,
                        preserveAspectRatio=False,
                        mask="auto",
                    )
                except Exception:
                    draw_wrapped_text(
                        c,
                        x,
                        p2_frame_bottom,
                        cw,
                        p2_frame_height,
                        "تعذر تحميل الصورة الجوية",
                        font_name="Naskh",
                        font_size=9,
                        min_size=7,
                        color=colors.grey,
                    )
            else:
                draw_wrapped_text(
                    c,
                    x,
                    p2_frame_bottom,
                    cw,
                    p2_frame_height,
                    "إطار الصورة الجوية",
                    font_name="Naskh",
                    font_size=10,
                    min_size=8,
                    color=colors.grey,
                )

        draw_footer_bar(2, 2)
        c.save()

    else:
        # ══════════════════════════════════════════════════════
        # الإسقاط المساحي (صفحة واحدة - الوضع الأصلي)
        # ══════════════════════════════════════════════════════
        y -= H_ROW + H_SECTION
        draw_section_title(
            c,
            x,
            y,
            cw,
            H_SECTION,
            "الإسقاط المساحي",
        )

        frame_top = y - 0.08 * cm
        frame_height = frame_top - frame_bottom

        if frame_height > 0.5 * cm:
            image_margin = 0.15 * cm
            image_x = x + image_margin
            image_y = frame_bottom + image_margin
            image_w = cw - image_margin * 2
            image_h = frame_height - image_margin * 2

            c.setFillColor(C_LIGHT)
            c.rect(
                x,
                frame_bottom,
                cw,
                frame_height,
                fill=1,
                stroke=0,
            )
            draw_border(
                c,
                x,
                frame_bottom,
                cw,
                frame_height,
                width=0.7,
            )

            if aerial_image and os.path.exists(aerial_image):
                try:
                    img = ImageReader(aerial_image)
                    c.drawImage(
                        img,
                        image_x,
                        image_y,
                        width=image_w,
                        height=image_h,
                        preserveAspectRatio=False,
                        mask="auto",
                    )
                except Exception:
                    draw_wrapped_text(
                        c,
                        x,
                        frame_bottom,
                        cw,
                        frame_height,
                        "تعذر تحميل الصورة الجوية",
                        font_name="Naskh",
                        font_size=9,
                        min_size=7,
                        color=colors.grey,
                    )
            else:
                draw_wrapped_text(
                    c,
                    x,
                    frame_bottom,
                    cw,
                    frame_height,
                    "إطار الصورة الجوية",
                    font_name="Naskh",
                    font_size=10,
                    min_size=8,
                    color=colors.grey,
                )

        draw_footer_bar(1, 1)
        c.save()

    return output_path
