
"""واجهة رئيسية: معاينة التقرير + أزرار جانبية + تعديل العناوين."""

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from clipboard_reader import read_clipboard
from parser import parse_clipboard, validate, build_ordered_data
from pdf_generator import generate_pdf
from config import (
    REQUIRED_FIELDS, FIELD_ORDER,
    DEFAULT_MAIN_TITLE, DEFAULT_COMPANY_TITLE,
)


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.data = {}
        self.aerial_image = None
        self.main_title = DEFAULT_MAIN_TITLE
        self.company_title = DEFAULT_COMPANY_TITLE

        root.title("نظام إنشاء تقرير مساحي")
        root.geometry("1200x820")
        root.configure(bg="#F0F0F0")

        main_frame = tk.Frame(root, bg="#F0F0F0")
        main_frame.pack(fill="both", expand=True, padx=15, pady=15)

        # ═══ الجانب الأيسر: المعاينة ═══
        preview_frame = tk.Frame(main_frame, bg="white",
                                 highlightbackground="#CCCCCC",
                                 highlightthickness=1)
        preview_frame.pack(side="left", fill="both", expand=True)

        tk.Label(
            preview_frame, text="📄 معاينة التقرير",
            font=("Segoe UI", 13, "bold"),
            bg="white", fg="#113A62"
        ).pack(pady=(10, 5))

        tree_frame = tk.Frame(preview_frame, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.tree = ttk.Treeview(
            tree_frame, columns=("field", "value"),
            show="headings", height=30
        )
        self.tree.heading("field", text="الحقل")
        self.tree.heading("value", text="القيمة")
        self.tree.column("field", width=280, anchor="e")
        self.tree.column("value", width=450, anchor="e")

        scroll = ttk.Scrollbar(tree_frame, orient="vertical",
                                command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        # ═══ الجانب الأيمن: التحكم ═══
        side_frame = tk.Frame(main_frame, bg="#F0F0F0", width=240)
        side_frame.pack(side="right", fill="y", padx=(15, 0))
        side_frame.pack_propagate(False)

        tk.Label(
            side_frame, text="التحكم",
            font=("Segoe UI", 12, "bold"),
            bg="#F0F0F0", fg="#113A62"
        ).pack(pady=(0, 10))

        self._make_button(side_frame, "📋  لصق البيانات", self.on_paste, "#2E75B6")
        self._make_button(side_frame, "✏️  تعديل القيم", self.on_edit, "#2E75B6")
        self._make_button(side_frame, "🏷️  تعديل العناوين", self.on_edit_titles, "#8E44AD")
        self._make_button(side_frame, "🖼️  رفع الصورة الجوية", self.on_upload_image, "#8E44AD")
        self._make_button(side_frame, "🗑️  إزالة الصورة", self.on_remove_image, "#C92A2A")
        self._make_button(side_frame, "🖨  طباعة PDF", self.on_print, "#2F9E44")

        # حالة الصورة
        self.image_status_var = tk.StringVar(value="لا توجد صورة")
        tk.Label(
            side_frame, textvariable=self.image_status_var,
            font=("Segoe UI", 8), bg="#F0F0F0", fg="#666",
            wraplength=220
        ).pack(pady=3)

        # حالة العناوين
        self.titles_var = tk.StringVar(
            value=f"📌 {self.main_title}"
        )
        tk.Label(
            side_frame, textvariable=self.titles_var,
            font=("Segoe UI", 8), bg="#F0F0F0", fg="#8E44AD",
            wraplength=220
        ).pack(pady=3)

        # اسم الملف
        self.file_var = tk.StringVar(value="")
        tk.Label(
            side_frame, textvariable=self.file_var,
            font=("Segoe UI", 8), bg="#F0F0F0", fg="#2F9E44",
            wraplength=220
        ).pack(side="bottom", pady=5)

        # الحالة العامة
        self.status_var = tk.StringVar(value="● لا توجد بيانات")
        self.status_label = tk.Label(
            side_frame, textvariable=self.status_var,
            font=("Segoe UI", 9), bg="#F0F0F0", fg="#888",
            wraplength=220
        )
        self.status_label.pack(side="bottom", pady=5)

    def _make_button(self, parent, text, command, color="#2E75B6"):
        btn = tk.Button(
            parent, text=text, command=command,
            font=("Segoe UI", 10, "bold"),
            bg=color, fg="white",
            activebackground="#1F4E79", activeforeground="white",
            relief="flat", padx=10, pady=9,
            cursor="hand2", width=22
        )
        btn.pack(pady=4)
        return btn

    def set_status(self, text, color="#333"):
        self.status_var.set(text)
        self.status_label.configure(fg=color)

    def refresh_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for key, value in self.data.items():
            if value:
                self.tree.insert("", "end", values=(key, value))

    # ═══ لصق ═══
    def on_paste(self):
        text = read_clipboard()
        if not text:
            messagebox.showwarning("الحافظة فارغة",
                                    "انسخ البيانات من إضافة المتصفح أولًا.")
            return

        data = parse_clipboard(text)
        if not data:
            messagebox.showerror("خطأ في البيانات",
                                  "لم يتم التعرف على صيغة البيانات.")
            return

        ok, missing = validate(data, REQUIRED_FIELDS)
        if not ok:
            messagebox.showwarning(
                "حقول ناقصة",
                "الحقول التالية فارغة:\n\n- " + "\n- ".join(missing)
            )

        self.data = build_ordered_data(data, FIELD_ORDER)
        filled = sum(1 for v in self.data.values() if v)
        self.set_status(f"✓ {filled} حقلًا", "#2F9E44")
        self.refresh_tree()

    # ═══ تعديل القيم ═══
    def on_edit(self):
        if not self.data:
            messagebox.showinfo("تنبيه", "الصق البيانات أولًا.")
            return

        edit_win = tk.Toplevel(self.root)
        edit_win.title("تعديل القيم")
        edit_win.geometry("750x650")

        canvas = tk.Canvas(edit_win, bg="white")
        scroll = ttk.Scrollbar(edit_win, orient="vertical",
                                command=canvas.yview)
        inner = tk.Frame(canvas, bg="white")

        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)

        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        entries = {}

        for key, value in self.data.items():
            row = tk.Frame(inner, bg="white")
            row.pack(fill="x", padx=10, pady=3)

            tk.Label(row, text=key, font=("Segoe UI", 9, "bold"),
                     bg="white", width=30, anchor="e").pack(side="right", padx=5)

            e = tk.Entry(row, font=("Segoe UI", 9), width=50, justify="right")
            e.insert(0, value)
            e.pack(side="right", padx=5, fill="x", expand=True)
            entries[key] = e

        def save():
            for k, e in entries.items():
                self.data[k] = e.get()
            self.refresh_tree()
            edit_win.destroy()
            self.set_status("✓ تم تعديل القيم", "#2F9E44")

        tk.Button(edit_win, text="💾 حفظ التعديلات", command=save,
                  font=("Segoe UI", 10, "bold"), bg="#2F9E44", fg="white",
                  padx=20, pady=8).pack(side="bottom", pady=10)

    # ═══ تعديل العناوين ═══
    def on_edit_titles(self):
        win = tk.Toplevel(self.root)
        win.title("تعديل العناوين")
        win.geometry("500x280")
        win.configure(bg="white")

        tk.Label(win, text="🏷️ تعديل العناوين",
                 font=("Segoe UI", 13, "bold"),
                 bg="white", fg="#113A62").pack(pady=(15, 10))

        # العنوان الرئيسي
        frame1 = tk.Frame(win, bg="white")
        frame1.pack(fill="x", padx=20, pady=8)
        tk.Label(frame1, text="العنوان الرئيسي:",
                 font=("Segoe UI", 10, "bold"),
                 bg="white", width=18, anchor="e").pack(side="right")
        main_entry = tk.Entry(frame1, font=("Segoe UI", 10),
                              justify="right", width=30)
        main_entry.insert(0, self.main_title)
        main_entry.pack(side="right", padx=5)

        # عنوان الشركة
        frame2 = tk.Frame(win, bg="white")
        frame2.pack(fill="x", padx=20, pady=8)
        tk.Label(frame2, text="عنوان الشركة:",
                 font=("Segoe UI", 10, "bold"),
                 bg="white", width=18, anchor="e").pack(side="right")
        company_entry = tk.Entry(frame2, font=("Segoe UI", 10),
                                 justify="right", width=30)
        company_entry.insert(0, self.company_title)
        company_entry.pack(side="right", padx=5)

        def save_titles():
            self.main_title = main_entry.get().strip() or DEFAULT_MAIN_TITLE
            self.company_title = company_entry.get().strip() or DEFAULT_COMPANY_TITLE
            self.titles_var.set(f"📌 {self.main_title}")
            self.set_status("✓ تم تعديل العناوين", "#2F9E44")
            win.destroy()

        def reset_titles():
            main_entry.delete(0, "end")
            main_entry.insert(0, DEFAULT_MAIN_TITLE)
            company_entry.delete(0, "end")
            company_entry.insert(0, DEFAULT_COMPANY_TITLE)

        btn_frame = tk.Frame(win, bg="white")
        btn_frame.pack(pady=20)

        tk.Button(btn_frame, text="💾 حفظ", command=save_titles,
                  font=("Segoe UI", 10, "bold"), bg="#2F9E44", fg="white",
                  padx=20, pady=8).pack(side="right", padx=5)

        tk.Button(btn_frame, text="↺ إعادة الافتراضي", command=reset_titles,
                  font=("Segoe UI", 10, "bold"), bg="#F39C12", fg="white",
                  padx=20, pady=8).pack(side="right", padx=5)

    # ═══ رفع الصورة الجوية ═══
    def on_upload_image(self):
        path = filedialog.askopenfilename(
            title="اختر الصورة الجوية",
            filetypes=[
                ("ملفات الصور", "*.png *.jpg *.jpeg *.bmp"),
                ("جميع الملفات", "*.*"),
            ]
        )
        if not path:
            return

        self.aerial_image = path
        fname = os.path.basename(path)
        if len(fname) > 30:
            fname = fname[:27] + "..."
        self.image_status_var.set(f"✓ {fname}")

    def on_remove_image(self):
        self.aerial_image = None
        self.image_status_var.set("لا توجد صورة")

    # ═══ طباعة ═══
    def on_print(self):
        if not self.data:
            messagebox.showinfo("تنبيه", "الصق البيانات أولًا.")
            return

        try:
            path = generate_pdf(
                self.data,
                aerial_image=self.aerial_image,
                main_title=self.main_title,
                company_title=self.company_title,
            )
            self.file_var.set(f"✓ {os.path.basename(path)}")
            self.set_status("✓ تم إنشاء التقرير", "#2F9E44")

            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                os.system(f'open "{path}"')
            else:
                os.system(f'xdg-open "{path}"')
        except Exception as e:
            messagebox.showerror("خطأ", f"تعذر إنشاء PDF:\n{e}")
            self.set_status("✗ فشل الإنشاء", "#C92A2A")


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()