
"""توليد تقرير PDF مطابق لفورمة Excel الرسمية — صفحة واحدة."""

import os
import re
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

import arabic_reshaper
from bidi.algorithm import get_display

from config import (
    FONT_REGULAR, FONT_BOLD, LOGO_RER, LOGO_QR,
    OUTPUT_DIR, COLOR_PRIMARY, COLOR_COMPANY,
    DEFAULT_MAIN_TITLE, DEFAULT_COMPANY_TITLE,
)


PAGE_W, PAGE_H = A4
MARGIN = 0.8 * cm
CONTENT_W = PAGE_W - 2 * MARGIN
CONTENT_H = PAGE_H - 2 * MARGIN

C_PRIMARY = colors.HexColor(COLOR_PRIMARY)
C_WHITE = colors.white
C_BLACK = colors.black
C_LIGHT = colors.HexColor("#FAFAFA")
C_COMPANY = colors.HexColor(COLOR_COMPANY)

RADIUS = 4


def ar(text):
    if text is None or text == "":
        return ""
    reshaped = arabic_reshaper.reshape(str(text))
    return get_display(reshaped)


def register_fonts():
    pdfmetrics.registerFont(TTFont("Naskh", FONT_REGULAR))
    pdfmetrics.registerFont(TTFont("Naskh-Bold", FONT_BOLD))


def draw_border(c, x, y, w, h, width=0.5):
    c.setStrokeColor(C_BLACK)
    c.setLineWidth(width)
    c.rect(x, y, w, h, fill=0, stroke=1)
    c.setLineWidth(0.5)


def draw_rounded_top(c, x, y, w, h, radius=RADIUS):
    c.setFillColor(C_PRIMARY)
    p = c.beginPath()
    p.moveTo(x, y)
    p.lineTo(x, y + h - radius)
    p.arcTo(x, y + h - 2 * radius, x + 2 * radius, y + h, 180, -90)
    p.lineTo(x + w - radius, y + h)
    p.arcTo(x + w - 2 * radius, y + h - 2 * radius, x + w, y + h, 90, -90)
    p.lineTo(x + w, y)
    p.close()
    c.drawPath(p, fill=1, stroke=0)


def draw_section_title(c, x, y, w, h, text):
    draw_rounded_top(c, x, y, w, h)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 11)
    c.drawCentredString(x + w / 2, y + h / 2 - 4, ar(text))


def draw_label(c, x, y, w, h, text, size=8):
    c.setFillColor(C_PRIMARY)
    c.rect(x, y, w, h, fill=1, stroke=0)
    draw_border(c, x, y, w, h)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", size)
    c.drawCentredString(x + w / 2, y + h / 2 - 3, ar(text))


def draw_value(c, x, y, w, h, text, size=8, bg=None, border=True):
    if bg:
        c.setFillColor(bg)
        c.rect(x, y, w, h, fill=1, stroke=0)
    if border:
        draw_border(c, x, y, w, h)
    c.setFillColor(C_BLACK)
    c.setFont("Naskh", size)
    text = ar(text) if text else ""
    c.drawCentredString(x + w / 2, y + h / 2 - 3, text)


def draw_paragraph(c, x, y, w, h, text, size=8, bg=None, border=True):
    if bg:
        c.setFillColor(bg)
        c.rect(x, y, w, h, fill=1, stroke=0)
    if border:
        draw_border(c, x, y, w, h)

    c.setFillColor(C_BLACK)
    c.setFont("Naskh", size)

    text = ar(text)
    char_w = size * 0.5
    max_chars = max(int((w - 6) / char_w), 20)

    words = text.split()
    lines = []
    current = ""
    for w_ in words:
        candidate = (current + " " + w_).strip()
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = w_
    if current:
        lines.append(current)

    line_h = size + 1.5
    total_h = line_h * len(lines)
    start_y = y + h / 2 + total_h / 2 - line_h

    for i, line in enumerate(lines):
        c.drawCentredString(x + w / 2, start_y - i * line_h, line)


def generate_qr(data: dict, path: str):
    try:
        import qrcode
        qr_text = (
            f"{data.get('رقم صك وزارة العدل', '')}|"
            f"{data.get('رقم القطعة بالمخطط', '')}"
        )
        img = qrcode.make(qr_text)
        img.save(path)
        return True
    except Exception:
        return False


def generate_pdf(data: dict, output_path: str | None = None,
                 aerial_image: str | None = None,
                 main_title: str | None = None,
                 company_title: str | None = None) -> str:

    register_fonts()
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if not output_path:
        parcel = data.get("رقم القطعة بالمخطط", "unknown")
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        output_path = os.path.join(OUTPUT_DIR, f"Report_{parcel}_{ts}.pdf")

    # العناوين القابلة للتعديل
    title_text = main_title if main_title else DEFAULT_MAIN_TITLE
    company_text = company_title if company_title else DEFAULT_COMPANY_TITLE

    c = canvas.Canvas(output_path, pagesize=A4)
    c.setTitle(title_text)

    coord_indices = set()
    for key in data.keys():
        m = re.match(r"^الإحداثي (الشمالي \(N\)|الشرقي \(E\)) (\d+)$", key)
        if m:
            coord_indices.add(int(m.group(2)))
    sorted_idx = sorted(coord_indices) if coord_indices else [1, 2, 3, 4]

    x = MARGIN
    cw = CONTENT_W
    col_w = cw / 10

    def colx(col_num):
        return x + (col_num - 1) * col_w

    H_HEADER = 2.2 * cm
    H_SECTION = 0.52 * cm
    H_ROW = 0.48 * cm
    H_COORD = 0.40 * cm
    H_2ROWS = H_ROW * 2

    y = PAGE_H - MARGIN

    # ═══ الصفوف 1-4: QR + العنوان + RER ═══
    header_y = y - H_HEADER
    qr_x = colx(1)
    qr_w = col_w * 3

    try:
        qr_path = LOGO_QR
        if not os.path.exists(qr_path):
            qr_path = os.path.join(OUTPUT_DIR, "_qr_temp.png")
            generate_qr(data, qr_path)
        if os.path.exists(qr_path):
            c.drawImage(
                qr_path, qr_x + 0.2 * cm, header_y + 0.1 * cm,
                width=qr_w - 0.4 * cm, height=H_HEADER - 0.2 * cm,
                preserveAspectRatio=True, mask="auto"
            )
    except Exception:
        pass

    title_x = colx(4)
    title_w = col_w * 4
    c.setFillColor(C_PRIMARY)
    c.setFont("Naskh-Bold", 22)
    c.drawCentredString(
        title_x + title_w / 2,
        header_y + H_HEADER / 2 - 6,
        ar(title_text)
    )

    rer_x = colx(8)
    rer_w = col_w * 3
    if os.path.exists(LOGO_RER):
        try:
            c.drawImage(
                LOGO_RER, rer_x + 0.2 * cm, header_y + 0.1 * cm,
                width=rer_w - 0.4 * cm, height=H_HEADER - 0.2 * cm,
                preserveAspectRatio=True, mask="auto"
            )
        except Exception:
            pass

    y = header_y

    # ═══ الصف 5: معلومات التقرير ═══
    y -= H_SECTION
    draw_section_title(c, x, y, cw, H_SECTION, "معلومات التقرير")

    # ═══ الصفوف 6-8 ═══
    report_date = datetime.now().strftime("%Y-%m-%d")
    rows_6_8 = [
        (report_date, "تاريخ التقرير", report_date, "رقم التقرير"),
        (data.get("تاريخ الصك", ""), "تاريخ الصك",
         data.get("رقم صك وزارة العدل", ""), "رقم صك وزارة العدل"),
        (data.get("رقم الهوية", ""), "رقم الهوية",
         data.get("اسم المالك", ""), "اسم المالك"),
    ]

    for val_a, label_c, val_dh, label_ij in rows_6_8:
        y -= H_ROW
        draw_value(c, colx(1), y, col_w * 2, H_ROW, val_a, size=8)
        draw_label(c, colx(3), y, col_w, H_ROW, label_c, size=8)
        draw_value(c, colx(4), y, col_w * 5, H_ROW, val_dh, size=8)
        draw_label(c, colx(9), y, col_w * 2, H_ROW, label_ij, size=7)

    # قفل الحد السفلي لجدول معلومات التقرير
    c.setStrokeColor(C_BLACK)
    c.setLineWidth(1.2)
    c.line(x, y, x + cw, y)
    c.setLineWidth(0.5)

    # ═══ الصف 9: مدموج بدون حدود ═══
    y -= H_ROW
    draw_value(c, x, y, cw, H_ROW, "", bg=C_LIGHT, border=False)

    # ═══ الصف 10: معلومات العقار ═══
    y -= H_SECTION
    draw_section_title(c, x, y, cw, H_SECTION, "معلومات العقار")

    # ═══ الصف 11 ═══
    y -= H_ROW
    draw_label(c, colx(1), y, col_w * 2, H_ROW, "المدينة", size=7)
    draw_label(c, colx(3), y, col_w, H_ROW, "اسم الحي", size=7)
    draw_label(c, colx(4), y, col_w, H_ROW, "رقم البلوك", size=7)
    draw_label(c, colx(5), y, col_w, H_ROW, "رقم المخطط", size=7)
    draw_label(c, colx(6), y, col_w, H_ROW, "رقم القطعة بالمخطط", size=6)
    draw_label(c, colx(7), y, col_w * 4, H_ROW, "رقم العقار في طبقة الأراضي", size=7)

    # ═══ الصف 12 ═══
    y -= H_ROW
    draw_value(c, colx(1), y, col_w * 2, H_ROW,
               data.get("اسم المدينة", "") or data.get("المنطقة", ""))
    draw_value(c, colx(3), y, col_w, H_ROW, data.get("اسم الحي", ""))
    draw_value(c, colx(4), y, col_w, H_ROW, data.get("رقم البلوك", ""))
    draw_value(c, colx(5), y, col_w, H_ROW, data.get("رقم المخطط", ""))
    draw_value(c, colx(6), y, col_w, H_ROW, data.get("رقم القطعة بالمخطط", ""))
    draw_value(c, colx(7), y, col_w * 4, H_ROW,
               data.get("رقم السجل العقاري", ""), size=7)

    # قفل سفلي سميك لجدول العقار
    c.setStrokeColor(C_BLACK)
    c.setLineWidth(1.2)
    c.line(x, y, x + cw, y)
    c.setLineWidth(0.5)

    # ═══ الصفوف 13-14 ═══
    y_two = y - H_2ROWS
    h_two = H_2ROWS

    desc_w = col_w * 4
    draw_paragraph(c, colx(1), y_two, desc_w, h_two,
                   data.get("وصف العقار", ""), size=10)
    draw_label(c, colx(5), y_two, col_w * 2, h_two, "وصف العقار", size=9)

    draw_value(c, colx(7), y_two + H_ROW, col_w * 2, H_ROW,
               data.get("الحدود حسب طبقة الأراضي", ""), size=8)
    draw_value(c, colx(7), y_two, col_w * 2, H_ROW,
               data.get("الحدود حسب الصك", ""), size=8)

    draw_label(c, colx(9), y_two + H_ROW, col_w, H_ROW, "حسب طبقة الأراضي", size=6)
    draw_label(c, colx(9), y_two, col_w, H_ROW, "حسب الصك", size=7)

    draw_label(c, colx(10), y_two, col_w, h_two, "مساحة العقار", size=7)

    y = y_two

    # ═══ الصفوف 16-17 ═══
    y -= H_ROW
    draw_label(c, colx(1), y, col_w * 2, H_ROW, "الأبعاد حسب الطبيعة*", size=7)
    draw_label(c, colx(3), y, col_w * 2, H_ROW, "الأبعاد حسب الصك", size=7)

    y -= H_ROW
    draw_label(c, colx(1), y, col_w, H_ROW, "المجموع", size=6)
    draw_label(c, colx(2), y, col_w, H_ROW, "طول الضلع", size=6)
    draw_label(c, colx(3), y, col_w, H_ROW, "المجموع", size=6)
    draw_label(c, colx(4), y, col_w, H_ROW, "طول الضلع", size=6)

    merged_y = y
    merged_h = H_2ROWS

    c.setFillColor(C_PRIMARY)
    c.rect(colx(5), merged_y, col_w * 2, merged_h, fill=1, stroke=0)
    draw_border(c, colx(5), merged_y, col_w * 2, merged_h)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 9)
    c.drawCentredString(colx(5) + col_w, merged_y + merged_h / 2 - 3,
                        ar("الحدود حسب الطبيعة"))

    c.setFillColor(C_PRIMARY)
    c.rect(colx(7), merged_y, col_w * 2, merged_h, fill=1, stroke=0)
    draw_border(c, colx(7), merged_y, col_w * 2, merged_h)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 9)
    c.drawCentredString(colx(7) + col_w, merged_y + merged_h / 2 - 3,
                        ar("الحدود حسب الصك"))

    c.setFillColor(C_PRIMARY)
    c.rect(colx(9), merged_y, col_w * 2, merged_h, fill=1, stroke=0)
    draw_border(c, colx(9), merged_y, col_w * 2, merged_h)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 9)
    c.drawCentredString(colx(9) + col_w, merged_y + merged_h / 2 - 3,
                        ar("الإتجاه"))

    # ═══ الصفوف 18-21 ═══
    directions = [
        ("شمال", "أ"),
        ("جنوب", "ب"),
        ("شرق", "ج"),
        ("غرب", "د"),
    ]

    for i, (dir_name, letter) in enumerate(directions, start=1):
        y -= H_ROW
        draw_value(c, colx(1), y, col_w, H_ROW,
                   data.get(f"الأبعاد حسب طبقة الأراضي (المجموع) {i}", ""), size=7)
        draw_value(c, colx(2), y, col_w, H_ROW,
                   data.get(f"الأبعاد حسب طبقة الأراضي (طول الضلع) {i}", ""), size=7)
        draw_value(c, colx(3), y, col_w, H_ROW,
                   data.get(f"الأبعاد حسب الصك (المجموع) {i}", ""), size=7)
        draw_value(c, colx(4), y, col_w, H_ROW,
                   data.get(f"الأبعاد حسب الصك (طول الضلع) {i}", ""), size=7)
        draw_value(c, colx(5), y, col_w * 2, H_ROW,
                   data.get(f"الحدود حسب الطبيعة {i}", ""), size=7)
        draw_value(c, colx(7), y, col_w * 2, H_ROW,
                   data.get(f"الحدود حسب الصك {i}", ""), size=7)
        draw_value(c, colx(9), y, col_w, H_ROW, dir_name, size=8)
        draw_value(c, colx(10), y, col_w, H_ROW, letter, size=8)

    # ═══ الصف 22: المادة 13 ═══
    y -= H_ROW
    draw_paragraph(
        c, x, y, cw, H_ROW,
        "المساحة والأطوال بحسب طبقة الأراضي قد تختلف وفق لما ورد في المادة الثالثة عشر "
        "من اللائحة التنفيذية لنظام التسجيل العيني للعقار",
        size=7, bg=C_WHITE, border=True
    )

    # ═══ الصفوف 23-24: رأس الإحداثيات ═══
    y -= H_COORD * 2

    c.setFillColor(C_PRIMARY)
    c.rect(colx(1), y, col_w * 4, H_COORD * 2, fill=1, stroke=0)
    draw_border(c, colx(1), y, col_w * 4, H_COORD * 2)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 9)
    c.drawCentredString(colx(1) + col_w * 2, y + H_COORD - 3,
                        ar("الاحداثي شرق (E)"))

    c.setFillColor(C_PRIMARY)
    c.rect(colx(5), y, col_w * 4, H_COORD * 2, fill=1, stroke=0)
    draw_border(c, colx(5), y, col_w * 4, H_COORD * 2)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 9)
    c.drawCentredString(colx(5) + col_w * 2, y + H_COORD - 3,
                        ar("الاحداثي شمال (N)"))

    c.setFillColor(C_PRIMARY)
    c.rect(colx(9), y, col_w * 2, H_COORD * 2, fill=1, stroke=0)
    draw_border(c, colx(9), y, col_w * 2, H_COORD * 2)
    c.setFillColor(C_WHITE)
    c.setFont("Naskh-Bold", 9)
    c.drawCentredString(colx(9) + col_w, y + H_COORD - 3,
                        ar("الإحداثيات"))

    # ═══ الإحداثيات ═══
    for idx in sorted_idx:
        y -= H_COORD
        draw_value(c, colx(1), y, col_w * 4, H_COORD,
                   data.get(f"الإحداثي الشرقي (E) {idx}", ""), size=7)
        draw_value(c, colx(5), y, col_w * 4, H_COORD,
                   data.get(f"الإحداثي الشمالي (N) {idx}", ""), size=7)
        draw_value(c, colx(9), y, col_w * 2, H_COORD, str(idx), size=7)

    # ═══ SANSRS ═══
    y -= H_ROW * 1.5
    draw_paragraph(
        c, colx(1), y, col_w * 5, H_ROW * 1.5,
        "Note: All coordinates are in National Geodetic Reference Frame KSA-GRF17 "
        "as per Saudi Arabia National Spatial Reference System (SANSRS)",
        size=6
    )
    draw_paragraph(
        c, colx(6), y, col_w * 5, H_ROW * 1.5,
        "ملاحظة: جميع الاحداثيات بإطار المرجع الجيوديسي الوطني KSA-GRF17 بحسب "
        "المرجع المكاني الوطني للمملكة SANSRS",
        size=6
    )

    # ═══ UTM Zone ═══
    y -= H_ROW
    draw_value(c, colx(1), y, col_w * 3, H_ROW,
               "Universal Transverse Mercator (UTM) Zone:", size=7)
    draw_value(c, colx(4), y, col_w * 4, H_ROW,
               data.get("النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي", "38N"), size=8)
    draw_value(c, colx(8), y, col_w * 3, H_ROW,
               "النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي", size=6)

    # ═══ الصف 35: الإسقاط المساحي ═══
    y -= H_ROW + H_SECTION
    draw_section_title(c, x, y, cw, H_SECTION, "الإسقاط المساحي")

    # ═══ إطار الصورة الجوية ═══
    aerial_h = y - MARGIN - H_SECTION - 0.1 * cm
    if aerial_h > 0.5 * cm:
        if aerial_image and os.path.exists(aerial_image):
            try:
                img = ImageReader(aerial_image)
                c.drawImage(
                    img, x, MARGIN + H_SECTION,
                    width=cw, height=aerial_h,
                    preserveAspectRatio=True, anchor="c", mask="auto"
                )
                draw_border(c, x, MARGIN + H_SECTION, cw, aerial_h)
            except Exception:
                c.setFillColor(C_LIGHT)
                c.rect(x, MARGIN + H_SECTION, cw, aerial_h, fill=1, stroke=0)
                draw_border(c, x, MARGIN + H_SECTION, cw, aerial_h)
        else:
            c.setFillColor(C_LIGHT)
            c.rect(x, MARGIN + H_SECTION, cw, aerial_h, fill=1, stroke=0)
            draw_border(c, x, MARGIN + H_SECTION, cw, aerial_h)

            c.setFillColor(colors.grey)
            c.setFont("Naskh", 10)
            c.drawCentredString(
                x + cw / 2, MARGIN + H_SECTION + aerial_h / 2,
                ar("إطار الصورة الجوية")
            )

    # ═══ الصف 55: عنوان الشركة — نص فقط بلون أزرق فاتح ═══
    c.setFillColor(C_COMPANY)
    c.setFont("Naskh-Bold", 11)
    c.drawCentredString(x + cw / 2, MARGIN + H_SECTION / 2, ar(company_text))

    c.save()
    return output_path