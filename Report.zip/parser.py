
"""تحليل نص الحافظة إلى قاموس بيانات."""

import re

COORD_N_RE = re.compile(r"^الإحداثي الشمالي \(N\) (\d+)$")
COORD_E_RE = re.compile(r"^الإحداثي الشرقي \(E\) (\d+)$")


def normalize(text) -> str:
    if text is None:
        return ""
    text = str(text).replace("\u00a0", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def detect_separator(text: str):
    for sep in ["\t", "|", ";", ","]:
        if sep in text:
            return sep
    return None


def parse_clipboard(text: str) -> dict:
    if not text:
        return {}

    sep = detect_separator(text)
    if not sep:
        return {}

    data = {}
    lines = text.splitlines()

    for i, line in enumerate(lines):
        line = line.rstrip("\r\n")
        if not line.strip():
            continue

        if i == 0 and ("الحقل" in line and "القيمة" in line):
            continue

        if sep in line:
            parts = line.split(sep, 1)
            key = normalize(parts[0])
            value = normalize(parts[1]) if len(parts) > 1 else ""
            if key:
                data[key] = value

    return data


def validate(data: dict, required_fields: list):
    missing = [f for f in required_fields if not normalize(data.get(f, ""))]
    return (len(missing) == 0, missing)


def split_coordinates(data: dict):
    basic = {}
    coords = {}
    for key, value in data.items():
        if COORD_N_RE.match(key) or COORD_E_RE.match(key):
            coords[key] = value
        else:
            basic[key] = value
    return basic, coords


def sort_coordinates(coords: dict) -> dict:
    def sort_key(item):
        key = item[0]
        match = re.search(r"(\d+)$", key)
        num = int(match.group(1)) if match else 0
        is_north = "الشمالي" in key
        return (num, 0 if is_north else 1)

    return dict(sorted(coords.items(), key=sort_key))


def build_ordered_data(data: dict, field_order: list) -> dict:
    basic, coords = split_coordinates(data)
    ordered = {}

    for field in field_order:
        ordered[field] = basic.get(field, "")

    for key, value in basic.items():
        if key not in ordered:
            ordered[key] = value

    sorted_coords = sort_coordinates(coords)
    for key, value in sorted_coords.items():
        ordered[key] = value

    return ordered