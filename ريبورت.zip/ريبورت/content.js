
(() => {
  "use strict";

  /* ============================================================
   * إعدادات
   * ============================================================ */

  const CONFIG = {
    buttonId: "property-extractor-button",
    containerId: "property-extractor-container"
  };

  const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  const cleanText = (value) =>
    String(value ?? "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  function getFieldValue(el) {
    if (!el) return "";

    const candidates = [
      el.value,
      el.getAttribute("value"),
      el.textContent
    ];

    for (const value of candidates) {
      const cleaned = cleanText(value);

      if (
        cleaned !== "" &&
        cleaned !== "undefined" &&
        cleaned !== "null"
      ) {
        return cleaned;
      }
    }

    return "";
  }

  /* ============================================================
   * ترتيب الحقول
   * ============================================================ */

  const FINAL_FIELD_ORDER = [
    "رقم الطلب",
    "رقم صك وزارة العدل",
    "تاريخ الصك",


    "رقم السجل العقاري",
    "رقم القطعة بالمخطط",
    "رقم المخطط",
    "رقم البلوك",

    "اسم الحي",
    "اسم المدينة",

    "الحدود حسب طبقة الأراضي",
    "الحدود حسب الصك",
    "وصف العقار",

    "اتجاه 1",
    "الحدود حسب الصك 1",
    "الحدود حسب الطبيعة 1",
    "الأبعاد حسب الصك (طول الضلع) 1",
    "الأبعاد حسب الصك (المجموع) 1",
    "الأبعاد حسب طبقة الأراضي (طول الضلع) 1",
    "الأبعاد حسب طبقة الأراضي (المجموع) 1",

    "اتجاه 2",
    "الحدود حسب الصك 2",
    "الحدود حسب الطبيعة 2",
    "الأبعاد حسب الصك (طول الضلع) 2",
    "الأبعاد حسب الصك (المجموع) 2",
    "الأبعاد حسب طبقة الأراضي (طول الضلع) 2",
    "الأبعاد حسب طبقة الأراضي (المجموع) 2",

    "اتجاه 3",
    "الحدود حسب الصك 3",
    "الحدود حسب الطبيعة 3",
    "الأبعاد حسب الصك (طول الضلع) 3",
    "الأبعاد حسب الصك (المجموع) 3",
    "الأبعاد حسب طبقة الأراضي (طول الضلع) 3",
    "الأبعاد حسب طبقة الأراضي (المجموع) 3",

    "اتجاه 4",
    "الحدود حسب الصك 4",
    "الحدود حسب الطبيعة 4",
    "الأبعاد حسب الصك (طول الضلع) 4",
    "الأبعاد حسب الصك (المجموع) 4",
    "الأبعاد حسب طبقة الأراضي (طول الضلع) 4",
    "الأبعاد حسب طبقة الأراضي (المجموع) 4",

    "النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي"
  ];

  /* ============================================================
   * البحث عن الحقول
   * ============================================================ */

  function findByPlaceholder(text, excludeName = null) {
    const elements = document.querySelectorAll("input, textarea");

    for (const el of elements) {
      const placeholder = cleanText(
        el.getAttribute("placeholder") || el.placeholder || ""
      );

      if (
        (placeholder === text || placeholder.includes(text)) &&
        (!excludeName || !(el.name || "").includes(excludeName))
      ) {
        return el;
      }
    }

    return null;
  }

  function getInputValue(el) {
    if (!el) return "";

    const directValue = el.value;
    if (
      directValue !== undefined &&
      directValue !== null &&
      String(directValue).trim() !== ""
    ) {
      return cleanText(directValue);
    }

    const fiberKey = Object.keys(el).find(
      key => key.startsWith("__reactFiber$")
    );

    if (fiberKey) {
      let fiber = el[fiberKey];

      for (let i = 0; i < 15 && fiber; i++) {
        const props = fiber.memoizedProps;

        if (props?.control) {
          const control = props.control;

          const formValues =
            control?._formValues ||
            control?._defaultValues;

          if (formValues) {
            const name = el.name;

            const parts = name.split(".");
            let value = formValues;

            for (const part of parts) {
              if (value == null) break;
              value = value[part];
            }

            if (
              value !== undefined &&
              value !== null &&
              String(value).trim() !== ""
            ) {
              return cleanText(value);
            }
          }
        }

        fiber = fiber.return;
      }
    }

    const attrValue = el.getAttribute("value");

    if (
      attrValue !== undefined &&
      attrValue !== null &&
      String(attrValue).trim() !== ""
    ) {
      return cleanText(attrValue);
    }

    return "";
  }

  function getValueByPlaceholder(placeholder, excludeName = null) {
    const el = findByPlaceholder(placeholder, excludeName);

    if (!el) {
      return {
        value: "",
        element: null
      };
    }

    const value = getInputValue(el);

    return {
      value,
      element: el
    };
  }

  function getValueByName(name) {
    const el = document.querySelector(`[name="${CSS.escape(name)}"]`);

    if (!el) {
      return {
        value: "",
        element: null
      };
    }

    const value = getInputValue(el);

    return {
      value,
      element: el
    };
  }

  /* ============================================================
   * React Select
   * ============================================================ */

  function getReactSelectValue(input) {
    if (!input) {
      return {
        value: "",
        element: null
      };
    }

    let container =
      input.closest('[class*="control"]') ||
      input.parentElement;

    let value = "";

    for (let i = 0; i < 6 && container; i++) {
      const singleValue =
        container.querySelector('[class*="singleValue"]') ||
        container.querySelector('[class*="single-value"]');

      if (singleValue) {
        value = cleanText(singleValue.textContent);
        if (value) break;
      }

      container = container.parentElement;
    }

    return {
      value,
      element: input
    };
  }

  function getSelectByName(name) {
    const input = document.querySelector(`input[name="${CSS.escape(name)}"]`);

    if (!input) {
      return {
        value: "",
        element: null
      };
    }

    return getReactSelectValue(input);
  }

  function getSelectById(id) {
    const input = document.getElementById(id);

    if (!input) {
      return {
        value: "",
        element: null
      };
    }

    return getReactSelectValue(input);
  }

  /* ============================================================
   * رقم الطلب
   * ============================================================ */

  function extractApplicationNumber() {
    const re = /\bDU\d+\b/i;

    const elements = document.querySelectorAll(
      "span, p, div, td, h1, h2, h3"
    );

    for (const el of elements) {
      const text = cleanText(el.textContent);

      if (text.length > 200) continue;

      const match = text.match(re);

      if (match) {
        return match[0].toUpperCase();
      }
    }

    return "";
  }

  /* ============================================================
   * بيانات الصك
   * ============================================================ */

  function extractDeedData() {
    const result = {
      "رقم صك وزارة العدل": "",
      "تاريخ الصك": ""
    };

    // ============================================================
    // رقم صك وزارة العدل
    // المصدر المؤكد حسب الـ Selector
    // ============================================================

    const deedCell = document.querySelector(
      'table.borderTable-new tbody.overflow-y-auto tr.cursor-pointer td.p-3.font-normal.text-\\[14px\\].leading-5.text-center'
    );

    if (deedCell) {
      const value = cleanText(deedCell.textContent);

      if (value) {
        result["رقم صك وزارة العدل"] = value;
      }
    }

    // ============================================================
    // إذا لم يعمل الـ selector السابق
    // نستخدم XPath
    // ============================================================

    if (!result["رقم صك وزارة العدل"]) {
      const xpath =
        '/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[6]/div[7]/div[2]/table[1]/tbody[1]/tr[1]/td[1]';

      const xpathResult = document.evaluate(
        xpath,
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      );

      const cell = xpathResult.singleNodeValue;

      if (cell) {
        const value = cleanText(cell.textContent);

        if (value) {
          result["رقم صك وزارة العدل"] = value;
        }
      }
    }

    // ============================================================
    // تاريخ الصك
    // ============================================================

    const dateCells = document.querySelectorAll("td");

    for (const td of dateCells) {
      const value = cleanText(td.textContent);

      if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
        result["تاريخ الصك"] = value;
        break;
      }
    }

    return result;
  }

  /* ============================================================
   * بيانات المالك
   * ============================================================ */

  function extractOwnerData() {
    const result = {};

    const identityRegex = /^\d{10}$/;

    const identities = [];
    const names = [];

    const cells = document.querySelectorAll("td, p, span");

    for (const el of cells) {
      const text = cleanText(el.textContent);

      if (
        identityRegex.test(text) &&
        !identities.includes(text)
      ) {
        identities.push(text);
      }
    }

    const candidates = document.querySelectorAll(
      "td p.font-bold, td p[class*='font-bold'], td p[class*='text-[#4A6BA3]']"
    );

    for (const el of candidates) {
      const text = cleanText(el.textContent);

      if (
        text &&
        text.length > 2 &&
        /[\u0600-\u06FF]/.test(text) &&
        !/^\d+$/.test(text) &&
        !text.includes("المالك") &&
        !names.includes(text)
      ) {
        names.push(text);
      }
    }

    const maxOwners = Math.max(
      names.length,
      identities.length
    );

    for (let i = 0; i < maxOwners; i++) {
      const number = i + 1;

      result[`اسم المالك ${number}`] =
        names[i] || "";

      result[`رقم الهوية ${number}`] =
        identities[i] || "";
    }

    return result;
  }

  /* ============================================================
   * البيانات الأساسية
   * ============================================================ */

  function extractBasicData() {
    const result = {};

    const mappings = [
      ["رقم السجل العقاري", "رقم السجل العقاري"],
      ["رقم القطعة بالمخطط", "رقم القطعة بالمخطط"],
      ["رقم المخطط", "رقم المخطط"],
      ["رقم البلوك", "رقم البلوك"],
      [
        "النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي",
        "النطاق الجغرافي لإسقاط مركاتور المستعرض العالمي"
      ]
    ];

    for (const [field, placeholder] of mappings) {
      const r = getValueByPlaceholder(placeholder);

      result[field] = r.value;
    }

    const landBoundary = getValueByPlaceholder(
      "الحدود حسب طبقة الأراضي"
    );

    result["الحدود حسب طبقة الأراضي"] = landBoundary.value;

    const deedBoundary = getValueByPlaceholder(
      "الحدود حسب الصك",
      "directions."
    );

    result["الحدود حسب الصك"] = deedBoundary.value;

    const description =
      document.querySelector('textarea[name="description"]') ||
      document.querySelector('textarea[placeholder="وصف العقار"]');

    if (description) {
      result["وصف العقار"] = getInputValue(description);
    } else {
      result["وصف العقار"] = "";
    }

    const region = getSelectByName("region");
    result["المنطقة"] = region.value;

    const city = getSelectByName("city");
    result["اسم المدينة"] = city.value;

    const district = getSelectByName("district");
    result["اسم الحي"] = district.value;

    return result;
  }

  /* ============================================================
   * الاتجاهات
   * ============================================================ */

  const directionFields = [
    ["deedBoundry", "الحدود حسب الصك"],
    ["asBuiltBoundry", "الحدود حسب الطبيعة"],
    ["deedDimentionLength", "الأبعاد حسب الصك (طول الضلع)"],
    ["deedDimentionTotal", "الأبعاد حسب الصك (المجموع)"],
    ["asBuiltDimentionLength", "الأبعاد حسب طبقة الأراضي (طول الضلع)"],
    ["asBuiltDimentionTotal", "الأبعاد حسب طبقة الأراضي (المجموع)"]
  ];

  function extractDirections() {
    const result = {};

    for (let i = 0; i < 4; i++) {
      const number = i + 1;

      const hidden = document.querySelector(
        `input[name="directions.${i}.direction"]`
      );

      let directionValue = "";

      if (hidden) {
        const parent =
          hidden.closest("div") ||
          hidden.parentElement;

        const selectValue =
          parent?.querySelector('[class*="singleValue"]');

        directionValue = cleanText(
          selectValue?.textContent || ""
        );

        if (!directionValue) {
          const numeric = getInputValue(hidden);

          const directionMap = {
            "1": "الشمالية",
            "2": "الجنوبية",
            "3": "الشرقية",
            "4": "الغربية"
          };

          directionValue =
            directionMap[numeric] || numeric;
        }
      }

      result[`اتجاه ${number}`] = directionValue;

      for (const [namePart, label] of directionFields) {
        const input = document.querySelector(
          `input[name="directions.${i}.${namePart}"]`
        );

        const key = `${label} ${number}`;

        if (input) {
          let value = getInputValue(input);

          if (
            !value ||
            value === "0"
          ) {
            const fiberKey = Object.keys(input).find(
              k => k.startsWith("__reactFiber$")
            );

            let fiber = fiberKey ? input[fiberKey] : null;

            for (let level = 0; level < 10 && fiber; level++) {
              const props = fiber.memoizedProps;

              if (props?.control?._formValues) {
                const formValues = props.control._formValues;

                const direction = formValues?.directions?.[i];

                if (
                  direction &&
                  direction[namePart] !== undefined &&
                  direction[namePart] !== null &&
                  String(direction[namePart]).trim() !== ""
                ) {
                  value = cleanText(direction[namePart]);
                }

                break;
              }

              fiber = fiber.return;
            }
          }

          result[key] = value;
        } else {
          result[key] = "";
        }
      }
    }

    return result;
  }

  /* ============================================================
   * الإحداثيات
   * ============================================================ */

  function extractCoordinates() {
    const result = {};

    const groups = {};

    const inputs = document.querySelectorAll(
      'input[name*="coordinates."]'
    );

    inputs.forEach(input => {
      const name = input.name || "";

      const match = name.match(
        /coordinates\.(\d+)\.(northCordinate|eastCordinate|northCoordinate|eastCoordinate|north|east)/i
      );

      if (!match) return;

      const index = Number(match[1]);
      let type = match[2].toLowerCase();

      if (type.includes("north")) {
        type = "north";
      } else if (type.includes("east")) {
        type = "east";
      }

      if (!groups[index]) {
        groups[index] = {};
      }

      groups[index][type] = {
        value: getInputValue(input),
        element: input
      };
    });

    const indices = Object.keys(groups)
      .map(Number)
      .sort((a, b) => a - b);

    indices.forEach((index, position) => {
      const number = position + 1;
      const group = groups[index];

      result[`الإحداثي الشمالي (N) ${number}`] =
        group.north?.value || "";

      result[`الإحداثي الشرقي (E) ${number}`] =
        group.east?.value || "";
    });

    return result;
  }

  /* ============================================================
   * البحث عن القيم الظاهرة المهمة
   * ============================================================ */

  function extractVisibleExtraData() {
    const result = {};

    const paragraphs = [...document.querySelectorAll("p")];

    for (const p of paragraphs) {
      const text = cleanText(p.textContent);

      if (text === "اسم المدينة") {
        const parent = p.parentElement;

        const value = cleanText(
          parent?.textContent
            ?.replace("اسم المدينة", "")
        );

        if (
          value &&
          value !== "اسم المدينة"
        ) {
          result.__visibleCity = value;
        }
      }

      if (text === "اسم الحي") {
        const parent = p.parentElement;

        const value = cleanText(
          parent?.textContent
            ?.replace("اسم الحي", "")
        );

        if (
          value &&
          value !== "اسم الحي"
        ) {
          result.__visibleDistrict = value;
        }
      }
    }

    return result;
  }

  /* ============================================================
   * استخراج كل البيانات
   * ============================================================ */

  async function extractAllData() {
    await wait(300);

    const data = {};

    data["رقم الطلب"] = extractApplicationNumber();

    Object.assign(
      data,
      extractBasicData()
    );

    Object.assign(
      data,
      extractDeedData()
    );

    Object.assign(
      data,
      extractOwnerData()
    );

    Object.assign(
      data,
      extractDirections()
    );

    Object.assign(
      data,
      extractCoordinates()
    );

    const extra = extractVisibleExtraData();

    if (
      (!data["اسم المدينة"] || data["اسم المدينة"] === "N/A") &&
      extra.__visibleCity
    ) {
      data["اسم المدينة"] = extra.__visibleCity;
    }

    if (
      (!data["اسم الحي"] || data["اسم الحي"] === "N/A") &&
      extra.__visibleDistrict
    ) {
      data["اسم الحي"] = extra.__visibleDistrict;
    }

    const finalData = {};

    for (const field of FINAL_FIELD_ORDER) {
      const value = data[field];

      finalData[field] =
        cleanText(value) || "N/A";
    }

    /* ========================================================
     * إضافة المالكين بشكل ديناميكي
     * ======================================================== */

    const ownerNumbers = new Set();

    Object.keys(data).forEach(key => {
      const match = key.match(
        /^(اسم المالك|رقم الهوية) (\d+)$/
      );

      if (match) {
        ownerNumbers.add(Number(match[2]));
      }
    });

    [...ownerNumbers]
      .sort((a, b) => a - b)
      .forEach(number => {
        finalData[`اسم المالك ${number}`] =
          cleanText(
            data[`اسم المالك ${number}`]
          ) || "N/A";

        finalData[`رقم الهوية ${number}`] =
          cleanText(
            data[`رقم الهوية ${number}`]
          ) || "N/A";
      });

    const coordinateKeys = Object.keys(data)
      .filter(key =>
        /^الإحداثي (الشمالي \(N\)|الشرقي \(E\)) \d+$/.test(key)
      );

    const coordinateNumbers = new Set();

    for (const key of coordinateKeys) {
      const match = key.match(/(\d+)$/);

      if (match) {
        coordinateNumbers.add(Number(match[1]));
      }
    }

    [...coordinateNumbers]
      .sort((a, b) => a - b)
      .forEach(number => {
        finalData[`الإحداثي الشمالي (N) ${number}`] =
          cleanText(
            data[`الإحداثي الشمالي (N) ${number}`]
          ) || "N/A";

        finalData[`الإحداثي الشرقي (E) ${number}`] =
          cleanText(
            data[`الإحداثي الشرقي (E) ${number}`]
          ) || "N/A";
      });

    return finalData;
  }

  /* ============================================================
   * نسخ Excel — عمودين فقط
   * ============================================================ */

  async function copyToExcel(data) {
    const rows = [];

    rows.push([
      "الحقل",
      "القيمة"
    ]);

    for (const [field, value] of Object.entries(data)) {
      if (Array.isArray(value)) {
        for (const item of value) {
          rows.push([
            String(field || ""),
            String(item || "")
          ]);
        }
      } else {
        rows.push([
          String(field || ""),
          String(value || "")
        ]);
      }
    }

    const text = rows
      .map(row =>
        row
          .map(value =>
            String(value)
              .replace(/\t/g, " ")
              .replace(/\r?\n/g, " ")
          )
          .join("\t")
      )
      .join("\r\n");

    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      const textarea = document.createElement("textarea");

      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.left = "-9999px";

      document.body.appendChild(textarea);

      textarea.select();

      document.execCommand("copy");

      textarea.remove();
    }

    return text;
  }

  /* ============================================================
   * نافذة صغيرة للنتيجة
   * ============================================================ */

  function showResult(data) {
    const old = document.getElementById(
      "property-extractor-result"
    );

    if (old) {
      old.remove();
    }

    const box = document.createElement("div");

    box.id = "property-extractor-result";

    Object.assign(box.style, {
      position: "fixed",
      left: "20px",
      top: "20px",
      zIndex: "2147483647",
      background: "#ffffff",
      color: "#222",
      padding: "14px 18px",
      borderRadius: "12px",
      border: "2px solid #16a34a",
      boxShadow: "0 10px 30px rgba(0,0,0,.2)",
      fontFamily: "Arial,sans-serif",
      direction: "rtl",
      minWidth: "260px",
      fontSize: "14px"
    });

    const values = Object.values(data);

    const valid = values.filter(
      value =>
        value &&
        value !== "N/A"
    ).length;

    box.innerHTML = `
      <div style="
        font-weight:bold;
        color:#16a34a;
        font-size:16px;
        margin-bottom:6px;
      ">
        ✅ تم استخراج البيانات
      </div>

      <div>
        تم التعرف على <b>${valid}</b> قيمة
      </div>

      <div style="
        margin-top:6px;
        color:#666;
        font-size:12px;
      ">
        البيانات منسوخة إلى الحافظة
      </div>
    `;

    document.body.appendChild(box);

    setTimeout(() => {
      box.remove();
    }, 3500);
  }

  /* ============================================================
   * الزر
   * ============================================================ */

  function createButton() {

    /* ========================================================
     * إظهار الزر فقط في إحدى صفحتي الاستخراج
     * ======================================================== */

    if (!isExtractionPage()) {
      return;
    }

    if (
      document.getElementById(CONFIG.containerId)
    ) {
      return;
    }

    const container =
      document.createElement("div");

    container.id =
      CONFIG.containerId;

    Object.assign(container.style, {
      position: "fixed",
      left:
        localStorage.getItem(
          "propertyExtractorLeft"
        ) || "20px",
      bottom:
        localStorage.getItem(
          "propertyExtractorBottom"
        ) || "20px",
      zIndex: "2147483647"
    });

    const button =
      document.createElement("button");

    button.id =
      CONFIG.buttonId;

    button.textContent = "📥";

    button.title =
      "اضغط لاستخراج البيانات ونسخها إلى Excel";

    Object.assign(button.style, {
      width: "54px",
      height: "54px",
      borderRadius: "50%",
      border: "0",
      background: "#ffffff",
      color: "#087f5b",
      fontSize: "24px",
      cursor: "grab",
      boxShadow: "0 4px 15px rgba(0,0,0,.2)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    });

    /* ========================================================
     * السحب
     * ======================================================== */

    let dragging = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startBottom = 0;

    button.addEventListener(
      "pointerdown",
      event => {
        if (event.button !== 0) return;

        dragging = true;
        moved = false;

        startX = event.clientX;
        startY = event.clientY;

        const rect =
          container.getBoundingClientRect();

        startLeft = rect.left;
        startBottom =
          window.innerHeight -
          rect.bottom;

        button.style.cursor = "grabbing";

        button.setPointerCapture(
          event.pointerId
        );
      }
    );

    button.addEventListener(
      "pointermove",
      event => {
        if (!dragging) return;

        const dx =
          event.clientX - startX;

        const dy =
          event.clientY - startY;

        if (
          Math.abs(dx) > 4 ||
          Math.abs(dy) > 4
        ) {
          moved = true;
        }

        let left =
          startLeft + dx;

        let bottom =
          startBottom - dy;

        left = Math.max(
          0,
          Math.min(
            left,
            window.innerWidth -
            container.offsetWidth
          )
        );

        bottom = Math.max(
          0,
          Math.min(
            bottom,
            window.innerHeight -
            container.offsetHeight
          )
        );

        container.style.left =
          `${left}px`;

        container.style.bottom =
          `${bottom}px`;
      }
    );

    button.addEventListener(
      "pointerup",
      event => {
        if (!dragging) return;

        dragging = false;

        button.style.cursor = "grab";

        const rect =
          container.getBoundingClientRect();

        localStorage.setItem(
          "propertyExtractorLeft",
          `${rect.left}px`
        );

        localStorage.setItem(
          "propertyExtractorBottom",
          `${window.innerHeight - rect.bottom}px`
        );

        try {
          button.releasePointerCapture(
            event.pointerId
          );
        } catch { }
      }
    );

    /* ========================================================
     * الضغط
     * ======================================================== */

    button.addEventListener(
      "click",
      async () => {
        if (moved) {
          moved = false;
          return;
        }

        if (button.disabled) return;

        button.disabled = true;

        button.textContent = "⏳";

        try {

          /* ======================================================
           * المرحلة الأولى اليدوية:
           * صفحة تفاصيل الصك
           * ====================================================== */

          if (isDeedDetailsPage()) {

            const deedData = extractDeedData();
            const ownerData = extractOwnerData();

            const data = {
              "رقم صك وزارة العدل":
                cleanText(
                  deedData["رقم صك وزارة العدل"] || ""
                ) || "N/A",

              "تاريخ الصك":
                cleanText(
                  deedData["تاريخ الصك"] || ""
                ) || "N/A"
            };

            const ownerNumbers = new Set();

            Object.keys(ownerData).forEach(key => {
              const match = key.match(
                /^(اسم المالك|رقم الهوية) (\d+)$/
              );

              if (match) {
                ownerNumbers.add(
                  Number(match[2])
                );
              }
            });

            [...ownerNumbers]
              .sort((a, b) => a - b)
              .forEach(number => {

                data[`اسم المالك ${number}`] =
                  cleanText(
                    ownerData[
                    `اسم المالك ${number}`
                    ] || ""
                  ) || "N/A";

                data[`رقم الهوية ${number}`] =
                  cleanText(
                    ownerData[
                    `رقم الهوية ${number}`
                    ] || ""
                  ) || "N/A";
              });

            await copyToExcel(data);

            showResult(data);

          }

          /* ======================================================
           * المرحلة الثانية اليدوية:
           * صفحة بيانات العقار
           * ====================================================== */

          else if (isPropertyDataPage()) {

            const allData =
              await extractAllData();

            const data = {};

            for (
              const [field, value]
              of Object.entries(allData)
            ) {

              /* استبعاد بيانات الصك */
              if (
                field === "رقم صك وزارة العدل" ||
                field === "تاريخ الصك"
              ) {
                continue;
              }

              /* استبعاد بيانات الملاك */
              if (
                /^اسم المالك \d+$/.test(field) ||
                /^رقم الهوية \d+$/.test(field)
              ) {
                continue;
              }

              data[field] = value;
            }

            const count =
              Object.values(data)
                .filter(
                  value =>
                    value &&
                    value !== "N/A"
                ).length;

            if (!count) {
              throw new Error(
                "لم يتم العثور على أي بيانات."
              );
            }

            await copyToExcel(data);

            showResult(data);
          }

          else {
            throw new Error(
              "هذه الصفحة ليست صفحة تفاصيل الصك أو صفحة بيانات العقار."
            );
          }

          button.textContent = "✅";

          button.style.color =
            "#16a34a";

        } catch (error) {

          button.textContent =
            "❌";

          button.style.color =
            "#dc2626";

          alert(
            "حدث خطأ أثناء استخراج البيانات:\n\n" +
            error.message
          );

        } finally {

          setTimeout(() => {

            button.textContent =
              "📥";

            button.style.color =
              "#087f5b";

            button.disabled =
              false;

          }, 2500);
        }
      }
    );

    container.appendChild(button);

    document.body.appendChild(container);
  }

  /* ============================================================
   * تحديد صفحات الاستخراج
   * ============================================================ */

  function isDeedDetailsPage() {
    /* ========================================================
     * صفحة تفاصيل الصك
     *
     * نتحقق من وجود عناصر صفحة الصك نفسها،
     * وليس من قيمة واحدة فقط.
     * ======================================================== */

    const deedTable = document.querySelector(
      "table.borderTable-new"
    );

    const deedData = extractDeedData();
    const ownerData = extractOwnerData();

    const deedNumber = cleanText(
      deedData["رقم صك وزارة العدل"] || ""
    );

    const deedDate = cleanText(
      deedData["تاريخ الصك"] || ""
    );

    const ownerName = cleanText(
      ownerData["اسم المالك 1"] || ""
    );

    const ownerIdentity = cleanText(
      ownerData["رقم الهوية 1"] || ""
    );

    return (
      !!deedTable &&
      !!deedNumber &&
      !!deedDate &&
      !!ownerName &&
      !!ownerIdentity
    );
  }

  function isPropertyDataPage() {
    /* ========================================================
     * صفحة بيانات العقار
     *
     * نعتمد على وجود حقول العقار الموجودة أصلًا
     * في الكود.
     * ======================================================== */

    const propertyFields = [
      "رقم السجل العقاري",
      "رقم القطعة بالمخطط",
      "رقم المخطط",
      "رقم البلوك",
      "الحدود حسب طبقة الأراضي",
      "وصف العقار"
    ];

    let found = 0;

    for (const field of propertyFields) {
      const result =
        getValueByPlaceholder(field);

      if (result.element) {
        found++;
      }
    }

    /* يكفي وجود حقلين أو أكثر للتأكد من الصفحة */
    return found >= 2;
  }

  function isExtractionPage() {
    return (
      isDeedDetailsPage() ||
      isPropertyDataPage()
    );
  }

  function isExtractionPage() {
    return (
      isDeedDetailsPage() ||
      isPropertyDataPage()
    );
  }

  function startAutoWatcher() {

    /* ========================================================
     * مراقبة تغير الصفحة لإظهار/إخفاء الزر فقط
     *
     * لا يوجد أي نسخ تلقائي هنا.
     * ======================================================== */

    let updateTimer = null;

    const updateButton = () => {

      clearTimeout(updateTimer);

      updateTimer = setTimeout(() => {

        const existing =
          document.getElementById(
            CONFIG.containerId
          );

        const validPage =
          isExtractionPage();

        /* ----------------------------------------------------
         * إذا كانت الصفحة المطلوبة
         * والزر غير موجود → أنشئه
         * ---------------------------------------------------- */

        if (
          validPage &&
          !existing
        ) {
          createButton();
          return;
        }

        /* ----------------------------------------------------
         * إذا خرجنا من الصفحتين
         * → احذف الزر
         * ---------------------------------------------------- */

        if (
          !validPage &&
          existing
        ) {
          existing.remove();
        }

      }, 300);
    };

    const observer =
      new MutationObserver(() => {
        updateButton();
      });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    /* فحص أولي */
    updateButton();
  }

  /* ============================================================
   * تشغيل
   * ============================================================ */

  function init() {
    if (!document.body) {
      setTimeout(init, 500);
      return;
    }

    createButton();

    startAutoWatcher();
  }

  init();

})();