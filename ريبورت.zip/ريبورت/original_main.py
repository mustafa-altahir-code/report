"""الواجهة الرئيسية لنظام إنشاء التقرير المساحي."""

import os
import sys
import re
from datetime import datetime

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk

from clipboard_reader import read_clipboard
from parser import parse_clipboard, validate, build_ordered_data
from pdf_generator import generate_pdf

from config import (
    REQUIRED_FIELDS,
    FIELD_ORDER,
    DEFAULT_MAIN_TITLE,
    DEFAULT_COMPANY_TITLE,
    COLOR_PRIMARY,
)


class App:
    def __init__(self, root: tk.Tk):
        self.root = root

        self.data = {}
        self.aerial_image = None
        self.thumb_photo = None

        self.edit_entry = None
        self.edit_item = None
        self.edit_column = None

        self.output = self._get_output_folder()

        self._configure_window()
        self._build_ui()

    # ══════════════════════════════════════════════════════════
    # الإعدادات
    # ══════════════════════════════════════════════════════════

    def _get_output_folder(self):
        desktop = os.path.join(
            os.path.expanduser("~"),
            "Desktop",
        )
        folder = os.path.join(
            desktop,
            "Survey Reports",
        )
        os.makedirs(folder, exist_ok=True)
        return folder

    def _configure_window(self):
        self.root.title("نظام إنشاء تقرير مساحي")
        self.root.geometry("1080x700")
        self.root.minsize(920, 620)
        self.root.configure(bg="#F1F5F9")

        # رفع النافذة لمقدمة الشاشة عند التشغيل
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after_idle(self.root.attributes, "-topmost", False)
        self.root.focus_force()

    # ══════════════════════════════════════════════════════════
    # بناء الواجهة
    # ══════════════════════════════════════════════════════════

    def _build_ui(self):
        self._build_header()
        self._build_content()
        self._build_status_bar()

    def _build_header(self):
        header = tk.Frame(
            self.root,
            bg=COLOR_PRIMARY,
            height=54,
        )
        header.pack(fill="x")
        header.pack_propagate(False)

        # عنوان البرنامج في الشريط العلوي
        title_box = tk.Frame(header, bg=COLOR_PRIMARY)
        title_box.pack(side="right", padx=20, pady=8)

        tk.Label(
            title_box,
            text="نظام إنشاء التقرير المساحي",
            font=("Segoe UI", 13, "bold"),
            bg=COLOR_PRIMARY,
            fg="#FFFFFF",
        ).pack(side="right")

        tk.Label(
            title_box,
            text="  |  إصدار التقارير المساحية الرسمية",
            font=("Segoe UI", 9),
            bg=COLOR_PRIMARY,
            fg="#94A3B8",
        ).pack(side="right")

        # شارة مجلد المخرجات على اليسار
        folder_badge = tk.Frame(header, bg="#1A4975", padx=8, pady=3)
        folder_badge.pack(side="left", padx=15, pady=12)

        tk.Label(
            folder_badge,
            text="📁 مجلد الحفظ: Survey Reports",
            font=("Segoe UI", 8),
            bg="#1A4975",
            fg="#E2E8F0",
        ).pack()

    def _build_content(self):
        container = tk.Frame(
            self.root,
            bg="#F1F5F9",
        )
        container.pack(
            fill="both",
            expand=True,
            padx=14,
            pady=12,
        )

        # ──────────────────────────────────────────────────────
        # لوحة التحكم الجانبية (يمين)
        # ──────────────────────────────────────────────────────
        controls = tk.Frame(
            container,
            bg="#FFFFFF",
            width=220,
            highlightbackground="#CBD5E1",
            highlightthickness=1,
        )
        controls.pack(
            side="right",
            fill="y",
            padx=(10, 0),
        )
        controls.pack_propagate(False)

        tk.Label(
            controls,
            text="لوحة التحكم",
            font=("Segoe UI", 11, "bold"),
            bg="#FFFFFF",
            fg=COLOR_PRIMARY,
        ).pack(pady=(12, 8))

        # قسم البيانات
        self._make_button(
            controls,
            "📋  لصق البيانات",
            self.on_paste,
            bg="#1E5E8E",
            hover_bg="#16466B",
        )

        self._make_button(
            controls,
            "🧹  تفريغ البيانات",
            self.on_clear,
            bg="#64748B",
            hover_bg="#475569",
        )

        self._add_separator(controls)

        # قسم الصورة الجوية ومعاينتها
        self._make_button(
            controls,
            "🖼  رفع الصورة الجوية",
            self.on_upload_image,
            bg="#0D9488",
            hover_bg="#0F766E",
        )

        # إطار المعاينة المصغرة للصورة
        self.image_preview_canvas = tk.Canvas(
            controls,
            width=188,
            height=95,
            bg="#F8FAFC",
            highlightbackground="#E2E8F0",
            highlightthickness=1,
            bd=0,
        )
        self.image_preview_canvas.pack(padx=14, pady=(6, 4))
        self._update_image_preview()

        self.image_status_var = tk.StringVar(value="لا توجد صورة جوية")
        tk.Label(
            controls,
            textvariable=self.image_status_var,
            font=("Segoe UI", 8),
            bg="#FFFFFF",
            fg="#64748B",
            wraplength=180,
            justify="center",
        ).pack(padx=10, pady=(0, 4))

        self._make_button(
            controls,
            "🗑  حذف الصورة",
            self.on_remove_image,
            bg="#DC2626",
            hover_bg="#B91C1C",
            compact=True,
        )

        self._add_separator(controls)

        # قسم إنشاء الـ PDF وفتح المجلد
        self._make_button(
            controls,
            "🖨  إنشاء PDF",
            self.on_print,
            bg=COLOR_PRIMARY,
            hover_bg="#1E5E8E",
            bold=True,
            pady=8,
        )

        self._make_button(
            controls,
            "📁  فتح مجلد التقارير",
            self.on_open_folder,
            bg="#334155",
            hover_bg="#1E293B",
            compact=True,
        )

        self.file_var = tk.StringVar(value="")
        tk.Label(
            controls,
            textvariable=self.file_var,
            font=("Segoe UI", 8, "bold"),
            bg="#FFFFFF",
            fg="#15803D",
            wraplength=185,
            justify="center",
        ).pack(side="bottom", padx=10, pady=10)

        # ──────────────────────────────────────────────────────
        # جدول المعاينة (يسار)
        # ──────────────────────────────────────────────────────
        preview = tk.Frame(
            container,
            bg="#FFFFFF",
            highlightbackground="#CBD5E1",
            highlightthickness=1,
        )
        preview.pack(
            side="left",
            fill="both",
            expand=True,
        )

        top_bar = tk.Frame(
            preview,
            bg="#FFFFFF",
            height=42,
        )
        top_bar.pack(
            fill="x",
            padx=12,
            pady=(4, 0),
        )
        top_bar.pack_propagate(False)

        # عنوان الجدول وعداد الحقول على اليمين
        right_info = tk.Frame(top_bar, bg="#FFFFFF")
        right_info.pack(side="right", pady=8)

        tk.Label(
            right_info,
            text="معاينة بيانات التقرير",
            font=("Segoe UI", 11, "bold"),
            bg="#FFFFFF",
            fg=COLOR_PRIMARY,
        ).pack(side="right")

        self.counter_var = tk.StringVar(value="0 حقل")
        tk.Label(
            right_info,
            textvariable=self.counter_var,
            font=("Segoe UI", 8, "bold"),
            bg="#E2E8F0",
            fg="#334155",
            padx=7,
            pady=1,
        ).pack(side="right", padx=(8, 0))

        tk.Label(
            top_bar,
            text="* انقر مرتين على أي قيمة لتعديلها مباشرة",
            font=("Segoe UI", 8),
            bg="#FFFFFF",
            fg="#94A3B8",
        ).pack(
            side="left",
            pady=10,
        )

        table_frame = tk.Frame(
            preview,
            bg="#FFFFFF",
            highlightbackground="#CBD5E1",
            highlightthickness=1,
        )
        table_frame.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=(2, 10),
        )

        # تنسيق مخصص للجدول
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Custom.Treeview",
            background="#FFFFFF",
            fieldbackground="#FFFFFF",
            foreground="#1E293B",
            rowheight=28,
            font=("Segoe UI", 9),
            borderwidth=0,
            relief="flat",
        )

        style.configure(
            "Custom.Treeview.Heading",
            background=COLOR_PRIMARY,
            foreground="#FFFFFF",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padding=(6, 6),
        )

        style.map(
            "Custom.Treeview.Heading",
            background=[("active", "#1A4975")],
        )

        style.map(
            "Custom.Treeview",
            background=[("selected", "#E0EDF8")],
            foreground=[("selected", "#0F2A4A")],
        )

        self.tree = ttk.Treeview(
            table_frame,
            columns=("field", "value"),
            show="headings",
            style="Custom.Treeview",
        )

        self.tree.heading("field", text="الحقل")
        self.tree.heading("value", text="القيمة")

        self.tree.column(
            "field",
            width=220,
            anchor="e",
            stretch=False,
        )
        self.tree.column(
            "value",
            width=500,
            anchor="e",
            stretch=True,
        )

        # ألوان الصفوف المتبادلة
        self.tree.tag_configure("even", background="#FFFFFF")
        self.tree.tag_configure("odd", background="#F8FAFC")

        scroll = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.tree.yview,
        )
        self.tree.configure(yscrollcommand=scroll.set)

        scroll.pack(
            side="right",
            fill="y",
        )
        self.tree.pack(
            side="left",
            fill="both",
            expand=True,
        )

        self.tree.bind("<Double-1>", self._start_inline_edit)

    def _build_status_bar(self):
        self.status_var = tk.StringVar(value="جاهز — الصق البيانات للبدء")

        status_frame = tk.Frame(
            self.root,
            bg="#E2E8F0",
            height=26,
        )
        status_frame.pack(fill="x", side="bottom")
        status_frame.pack_propagate(False)

        tk.Label(
            status_frame,
            textvariable=self.status_var,
            bg="#E2E8F0",
            fg="#475569",
            font=("Segoe UI", 8),
            anchor="e",
            padx=12,
        ).pack(side="right", fill="y")

        tk.Label(
            status_frame,
            text="نظام التقرير المساحي v2.0",
            bg="#E2E8F0",
            fg="#94A3B8",
            font=("Segoe UI", 8),
            anchor="w",
            padx=12,
        ).pack(side="left", fill="y")

    # ══════════════════════════════════════════════════════════
    # المكونات المساعدة
    # ══════════════════════════════════════════════════════════

    def _make_button(
        self,
        parent,
        text,
        command,
        bg="#1E5E8E",
        hover_bg="#16466B",
        fg="white",
        bold=False,
        compact=False,
        pady=5,
    ):
        font_weight = "bold" if bold else "normal"
        button = tk.Button(
            parent,
            text=text,
            command=command,
            font=("Segoe UI", 9, font_weight),
            bg=bg,
            fg=fg,
            activebackground=hover_bg,
            activeforeground=fg,
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=10,
            pady=3 if compact else pady,
        )
        button.pack(
            fill="x",
            padx=14,
            pady=3 if compact else 4,
        )

        button.bind("<Enter>", lambda e: button.configure(bg=hover_bg))
        button.bind("<Leave>", lambda e: button.configure(bg=bg))

        return button

    @staticmethod
    def _add_separator(parent):
        sep = tk.Frame(parent, bg="#E2E8F0", height=1)
        sep.pack(fill="x", padx=14, pady=8)

    def set_status(self, text):
        self.status_var.set(text)

    # ══════════════════════════════════════════════════════════
    # تحديث وتعديل الجدول
    # ══════════════════════════════════════════════════════════

    def refresh_tree(self):
        self._cancel_inline_edit()

        for item in self.tree.get_children():
            self.tree.delete(item)

        idx = 0
        for key, value in self.data.items():
            if value is not None:
                tag = "even" if idx % 2 == 0 else "odd"
                self.tree.insert(
                    "",
                    "end",
                    values=(key, value),
                    tags=(tag,),
                )
                idx += 1

        filled = sum(1 for v in self.data.values() if v)
        self.counter_var.set(f"{filled} حقل")

    def _start_inline_edit(self, event):
        self._cancel_inline_edit()

        item = self.tree.identify_row(event.y)
        column = self.tree.identify_column(event.x)

        if not item or column != "#2":
            return

        bbox = self.tree.bbox(item, column)
        if not bbox:
            return

        x, y, width, height = bbox
        values = self.tree.item(item, "values")
        if len(values) < 2:
            return

        current_value = values[1]

        entry = tk.Entry(
            self.tree,
            font=("Segoe UI", 9),
            justify="right",
            relief="solid",
            bd=1,
            bg="#FFFDF2",
            fg="#0F172A",
        )

        entry.insert(0, current_value)
        entry.place(x=x, y=y, width=width, height=height)
        entry.focus_set()
        entry.select_range(0, "end")

        self.edit_entry = entry
        self.edit_item = item
        self.edit_column = column

        entry.bind("<Return>", lambda e: self._save_inline_edit())
        entry.bind("<Escape>", lambda e: self._cancel_inline_edit())
        entry.bind("<FocusOut>", lambda e: self._save_inline_edit())

    def _save_inline_edit(self):
        if not self.edit_entry or not self.edit_item:
            return

        value = self.edit_entry.get().strip()
        values = list(self.tree.item(self.edit_item, "values"))

        if len(values) >= 2:
            key = values[0]
            self.data[key] = value
            values[1] = value
            self.tree.item(self.edit_item, values=values)

        self._cancel_inline_edit()
        self.set_status("✓ تم حفظ تعديل الحقل")

    def _cancel_inline_edit(self):
        if self.edit_entry:
            try:
                self.edit_entry.destroy()
            except tk.TclError:
                pass

        self.edit_entry = None
        self.edit_item = None
        self.edit_column = None

    # ══════════════════════════════════════════════════════════
    # لصق وتفريغ البيانات
    # ══════════════════════════════════════════════════════════

    def on_paste(self):
        text = read_clipboard()

        if not text:
            messagebox.showwarning(
                "الحافظة فارغة",
                "انسخ البيانات من إضافة المتصفح أولًا.",
            )
            return

        data = parse_clipboard(text)

        if not data:
            messagebox.showerror(
                "خطأ في البيانات",
                "لم يتم التعرف على صيغة البيانات المنسوخة.",
            )
            return

        valid, missing = validate(data, REQUIRED_FIELDS)
        self.data = build_ordered_data(data, FIELD_ORDER)
        self.refresh_tree()

        filled = sum(1 for v in self.data.values() if v)

        if valid:
            self.set_status(f"✓ تم تحميل البيانات بنجاح — {filled} حقل")
        else:
            self.set_status(f"⚠ تم التحميل — يوجد {len(missing)} حقل ناقص")
            messagebox.showwarning(
                "حقول ناقصة",
                "الحقول التالية فارغة في البيانات المنسوخة:\n\n"
                + "\n".join(f"• {field}" for field in missing),
            )

    def on_clear(self):
        if not self.data and not self.aerial_image:
            return

        if self.data:
            if not messagebox.askyesno(
                "تأكيد التفريغ",
                "هل أنت متأكد من تفريغ كافة البيانات الحالية؟",
            ):
                return

        self._cancel_inline_edit()
        self.data = {}
        self.aerial_image = None
        self.refresh_tree()
        self._update_image_preview()
        self.image_status_var.set("لا توجد صورة جوية")
        self.file_var.set("")
        self.counter_var.set("0 حقل")
        self.set_status("✓ تم تفريغ البيانات بالكامل")

    # ══════════════════════════════════════════════════════════
    # إدارة ومعاينة الصورة الجوية
    # ══════════════════════════════════════════════════════════

    def _update_image_preview(self):
        self.image_preview_canvas.delete("all")

        if not self.aerial_image or not os.path.exists(self.aerial_image):
            # أيقونة ونص توضيحي عند عدم وجود صورة
            self.image_preview_canvas.create_text(
                94, 38,
                text="🖼",
                font=("Segoe UI", 16),
                fill="#94A3B8",
            )
            self.image_preview_canvas.create_text(
                94, 66,
                text="معاينة الصورة الجوية",
                font=("Segoe UI", 8),
                fill="#94A3B8",
            )
            self.thumb_photo = None
            return

        try:
            img = Image.open(self.aerial_image)
            img.thumbnail((182, 90), Image.Resampling.LANCZOS)
            self.thumb_photo = ImageTk.PhotoImage(img)
            self.image_preview_canvas.create_image(
                94, 47,
                image=self.thumb_photo,
                anchor="center",
            )
        except Exception:
            self.image_preview_canvas.create_text(
                94, 47,
                text="تعذر عرض المعاينة",
                font=("Segoe UI", 8),
                fill="#DC2626",
            )
            self.thumb_photo = None

    def on_upload_image(self):
        path = filedialog.askopenfilename(
            title="اختر الصورة الجوية",
            filetypes=[
                ("ملفات الصور", "*.png *.jpg *.jpeg *.bmp"),
                ("جميع الملفات", "*.*"),
            ],
        )

        if not path:
            return

        self.aerial_image = path
        filename = os.path.basename(path)
        if len(filename) > 22:
            filename = filename[:19] + "..."

        self.image_status_var.set(f"✓ {filename}")
        self._update_image_preview()
        self.set_status("✓ تم تحميل الصورة الجوية")

    def on_remove_image(self):
        if not self.aerial_image:
            return

        self.aerial_image = None
        self.image_status_var.set("لا توجد صورة جوية")
        self._update_image_preview()
        self.set_status("✓ تم حذف الصورة الجوية")

    # ══════════════════════════════════════════════════════════
    # إنشاء الـ PDF وفتح المجلد
    # ══════════════════════════════════════════════════════════

    def on_print(self):
        self._cancel_inline_edit()

        if not self.data:
            messagebox.showinfo(
                "تنبيه",
                "الصق البيانات أولًا قبل إنشاء التقرير.",
            )
            return

        try:
            order_no = str(self.data.get("رقم الطلب", "")).strip()
            safe_order_no = re.sub(r'[\\/*?:"<>|]', '_', order_no) if order_no else ""

            if safe_order_no:
                filename = f"{safe_order_no}.pdf"
            else:
                timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                parcel = str(
                    self.data.get("رقم القطعة بالمخطط", "unknown")
                ).strip() or "unknown"
                filename = f"Survey Report_{parcel}_{timestamp}.pdf"

            path = generate_pdf(
                self.data,
                output_path=os.path.join(
                    self.output,
                    filename,
                ),
                aerial_image=self.aerial_image,
                main_title=DEFAULT_MAIN_TITLE,
                company_title=DEFAULT_COMPANY_TITLE,
            )

            filename = os.path.basename(path)
            self.file_var.set(f"✓ {filename}")
            self.set_status(f"✓ تم إنشاء التقرير بنجاح: {filename}")
            self._open_file(path)

        except Exception as exc:
            messagebox.showerror(
                "خطأ",
                f"تعذر إنشاء ملف PDF:\n\n{exc}",
            )
            self.set_status("✗ فشل إنشاء التقرير")

    def on_open_folder(self):
        try:
            os.makedirs(self.output, exist_ok=True)
            if sys.platform.startswith("win"):
                os.startfile(self.output)
            elif sys.platform == "darwin":
                os.system(f'open "{self.output}"')
            else:
                os.system(f'xdg-open "{self.output}"')
            self.set_status("✓ تم فتح مجلد التقارير")
        except Exception as exc:
            messagebox.showerror(
                "خطأ",
                f"تعذر فتح مجلد التقارير:\n{exc}",
            )

    @staticmethod
    def _open_file(path):
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                os.system(f'open "{path}"')
            else:
                os.system(f'xdg-open "{path}"')
        except Exception:
            pass


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
