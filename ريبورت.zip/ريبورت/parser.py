"""تحليل نص الحافظة وترتيب البيانات ودمج المراحل المنفصلة."""

import re


COORD_N_RE = re.compile(r"^الإحداثي الشمالي \(N\) (\d+)$")
COORD_E_RE = re.compile(r"^الإحداثي الشرقي \(E\) (\d+)$")
OWNER_NAME_RE = re.compile(r"^اسم المالك(?: (\d+))?$")
OWNER_ID_RE = re.compile(r"^رقم الهوية(?: (\d+))?$")


def normalize(text) -> str:
    """تنظيف النص."""
    if text is None:
        return ""

    text = str(text).replace("\u00a0", " ")
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def detect_separator(text: str):
    """اكتشاف الفاصل المستخدم في بيانات الحافظة."""
    for separator in ("\t", "|", ";", ","):
        if separator in text:
            return separator

    return None


def parse_clipboard(text: str) -> dict:
    """تحويل بيانات الحافظة إلى قاموس."""
    if not text:
        return {}

    separator = detect_separator(text)

    if not separator:
        return {}

    data = {}

    for index, line in enumerate(text.splitlines()):
        line = line.rstrip("\r\n")

        if not line.strip():
            continue

        # تخطي عنوان الجدول
        if index == 0 and "الحقل" in line and "القيمة" in line:
            continue

        if separator not in line:
            continue

        key, value = line.split(separator, 1)

        key = normalize(key)
        value = normalize(value)

        # استبدال N/A بسلسلة فارغة لراحة المستخدم
        if value == "N/A":
            value = ""

        if key:
            data[key] = value

    return data


def detect_paste_type(data: dict) -> str:
    """
    تحديد نوع البيانات الملصقة:
    - 'deed': بيانات الصك والملاك (المرحلة 1)
    - 'property': بيانات العقار والإحداثيات (المرحلة 2)
    - 'all': بيانات شاملة لكلا المرحلتين
    """
    if not data:
        return "empty"

    has_deed = any(
        k in data or k.startswith("اسم المالك") or k.startswith("رقم الهوية")
        for k in ("رقم صك وزارة العدل", "تاريخ الصك")
    )
    has_property = any(
        k in data
        or k.startswith("الإحداثي الشمالي")
        or k.startswith("الحدود حسب")
        or k.startswith("الأبعاد حسب")
        for k in ("رقم القطعة بالمخطط", "رقم المخطط", "اسم الحي", "اسم المدينة", "وصف العقار")
    )

    if has_deed and has_property:
        return "all"
    elif has_deed:
        return "deed"
    elif has_property:
        return "property"
    return "general"


def validate(data: dict, required_fields: list):
    """
    التحقق من الحقول المطلوبة.
    يدعم التحقق من المالك سواء كان 'اسم المالك' أو 'اسم المالك 1'.
    """
    missing = []

    for field in required_fields:
        if field == "اسم المالك":
            val = normalize(data.get("اسم المالك 1", data.get("اسم المالك", "")))
            if not val:
                missing.append("اسم المالك")
        elif field == "رقم الهوية":
            val = normalize(data.get("رقم الهوية 1", data.get("رقم الهوية", "")))
            if not val:
                missing.append("رقم الهوية")
        else:
            if not normalize(data.get(field, "")):
                missing.append(field)

    return len(missing) == 0, missing


def split_coordinates(data: dict):
    """فصل الإحداثيات عن باقي البيانات."""
    basic = {}
    coords = {}

    for key, value in data.items():
        if COORD_N_RE.match(key) or COORD_E_RE.match(key):
            coords[key] = value
        else:
            basic[key] = value

    return basic, coords


def sort_coordinates(coords: dict) -> dict:
    """ترتيب الإحداثيات حسب رقم النقطة ثم الشمالي فالشرقي."""

    def sort_key(item):
        key = item[0]

        match = re.search(r"(\d+)$", key)
        number = int(match.group(1)) if match else 0

        is_north = "الشمالي" in key

        return number, 0 if is_north else 1

    return dict(
        sorted(coords.items(), key=sort_key)
    )


def build_ordered_data(data: dict, field_order: list) -> dict:
    """
    بناء قاموس مرتب منطقياً مع دعم الملاك المتعددين والإحداثيات.
    الترتيب:
    1. رأس التقرير والصك (رقم الطلب، رقم الصك، تاريخ الصك)
    2. كافة الملاك المرقمين تحت بعض (اسم المالك 1، رقم الهوية 1، اسم المالك 2، رقم الهوية 2...)
    3. معلومات العقار والأبعاد والحدود
    4. أي حقول إضافية
    5. جدول الإحداثيات مرتباً حسب النقاط
    """
    basic, coords = split_coordinates(data)

    # استخراج كافة أرقام الملاك
    owner_indices = set()
    for k in basic:
        m = re.match(r"^(?:اسم المالك|رقم الهوية) (\d+)$", k)
        if m:
            owner_indices.add(int(m.group(1)))

    ordered = {}

    # حقول ما قبل الملاك
    prefix_fields = ["رقم الطلب", "رقم صك وزارة العدل", "تاريخ الصك"]
    for field in prefix_fields:
        ordered[field] = basic.get(field, "")

    # إدراج الملاك بالترتيب
    if owner_indices:
        for idx in sorted(owner_indices):
            name_k = f"اسم المالك {idx}"
            id_k = f"رقم الهوية {idx}"
            ordered[name_k] = basic.get(name_k, "")
            ordered[id_k] = basic.get(id_k, "")
    else:
        # مالك افتراضي أول
        ordered["اسم المالك 1"] = basic.get("اسم المالك 1", basic.get("اسم المالك", ""))
        ordered["رقم الهوية 1"] = basic.get("رقم الهوية 1", basic.get("رقم الهوية", ""))

    # مالك غير مفهرس إذا كان موجوداً ولم يُدمج
    if "اسم المالك" in basic and "اسم المالك 1" not in basic:
        ordered["اسم المالك"] = basic["اسم المالك"]
    if "رقم الهوية" in basic and "رقم الهوية 1" not in basic:
        ordered["رقم الهوية"] = basic["رقم الهوية"]

    # باقي حقول العقار حسب FIELD_ORDER
    for field in field_order:
        if field not in prefix_fields and not re.match(r"^(?:اسم المالك|رقم الهوية)", field):
            ordered[field] = basic.get(field, "")

    # أي حقول أخرى
    for key, value in basic.items():
        if key not in ordered:
            ordered[key] = value

    # الإحداثيات في النهاية
    for key, value in sort_coordinates(coords).items():
        ordered[key] = value

    return ordered


def get_default_fields(field_order: list) -> dict:
    """
    إنشاء هيكل الحقول الافتراضية كاملة بقيم فارغة،
    لتكون الواجهة جاهزة للعمل اليدوي مباشرة فور فتح التطبيق.
    """
    default_dict = {}

    for field in field_order:
        default_dict[field] = ""

    # التأكد من وجود المالك الأول
    if "اسم المالك 1" not in default_dict:
        default_dict["اسم المالك 1"] = ""
    if "رقم الهوية 1" not in default_dict:
        default_dict["رقم الهوية 1"] = ""

    # إضافة 4 نقاط إحداثيات افتراضية
    for i in range(1, 5):
        default_dict[f"الإحداثي الشمالي (N) {i}"] = ""
        default_dict[f"الإحداثي الشرقي (E) {i}"] = ""

    return build_ordered_data(default_dict, field_order)


def merge_data(existing_data: dict, new_data: dict, field_order: list) -> dict:
    """
    دمج البيانات الجديدة القادمة من الحافظة (لصق منفصل) مع البيانات الحالية
    دون حذف أو مسح الحقول التي تم إدخالها أو لصقها مسبقاً.
    """
    merged = existing_data.copy() if existing_data else get_default_fields(field_order)

    for key, value in new_data.items():
        key = normalize(key)
        value = normalize(value)

        # دعم توافق اسم المالك غير المفهرس
        if key == "اسم المالك" and "اسم المالك 1" in merged:
            key = "اسم المالك 1"
        elif key == "رقم الهوية" and "رقم الهوية 1" in merged:
            key = "رقم الهوية 1"

        if value and value != "N/A":
            merged[key] = value
        elif key not in merged:
            merged[key] = value

    return build_ordered_data(merged, field_order)
