"""تحليل نص الحافظة وترتيب البيانات."""

import re


COORD_N_RE = re.compile(r"^الإحداثي الشمالي \(N\) (\d+)$")
COORD_E_RE = re.compile(r"^الإحداثي الشرقي \(E\) (\d+)$")


def normalize(text) -> str:
    """تنظيف النص."""
    if text is None:
        return ""

    text = str(text).replace("\u00a0", " ")
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def detect_separator(text: str):
    """اكتشاف الفاصل المستخدم في بيانات الحافظة."""
    for separator in ("\t", "|", ";", ","):
        if separator in text:
            return separator

    return None


def parse_clipboard(text: str) -> dict:
    """تحويل بيانات الحافظة إلى قاموس."""
    if not text:
        return {}

    separator = detect_separator(text)

    if not separator:
        return {}

    data = {}

    for index, line in enumerate(text.splitlines()):
        line = line.rstrip("\r\n")

        if not line.strip():
            continue

        # تخطي عنوان الجدول
        if index == 0 and "الحقل" in line and "القيمة" in line:
            continue

        if separator not in line:
            continue

        key, value = line.split(separator, 1)

        key = normalize(key)
        value = normalize(value)

        if key:
            data[key] = value

    return data


def validate(data: dict, required_fields: list):
    """التحقق من الحقول المطلوبة."""
    missing = [
        field
        for field in required_fields
        if not normalize(data.get(field, ""))
    ]

    return len(missing) == 0, missing


def split_coordinates(data: dict):
    """فصل الإحداثيات عن باقي البيانات."""
    basic = {}
    coords = {}

    for key, value in data.items():
        if COORD_N_RE.match(key) or COORD_E_RE.match(key):
            coords[key] = value
        else:
            basic[key] = value

    return basic, coords


def sort_coordinates(coords: dict) -> dict:
    """ترتيب الإحداثيات حسب رقم النقطة."""

    def sort_key(item):
        key = item[0]

        match = re.search(r"(\d+)$", key)
        number = int(match.group(1)) if match else 0

        is_north = "الشمالي" in key

        return number, 0 if is_north else 1

    return dict(
        sorted(coords.items(), key=sort_key)
    )


def build_ordered_data(data: dict, field_order: list) -> dict:
    """بناء قاموس مرتب."""
    basic, coords = split_coordinates(data)

    ordered = {}

    for field in field_order:
        ordered[field] = basic.get(field, "")

    # الحقول الإضافية غير الموجودة في القائمة
    for key, value in basic.items():
        if key not in ordered:
            ordered[key] = value

    # الإحداثيات في النهاية
    for key, value in sort_coordinates(coords).items():
        ordered[key] = value

    return ordered
