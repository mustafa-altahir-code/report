
"""قراءة النص من الحافظة."""

import pyperclip


def read_clipboard() -> str:
    try:
        text = pyperclip.paste()
        return text.strip() if text else ""
    except Exception as e:
        print(f"خطأ في قراءة الحافظة: {e}")
        return ""